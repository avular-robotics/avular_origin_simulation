// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:msg/LongitudalVelocityLimits.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__LONGITUDAL_VELOCITY_LIMITS_H_
#define ORIGIN_MSGS__MSG__LONGITUDAL_VELOCITY_LIMITS_H_

#include "origin_msgs/msg/detail/longitudal_velocity_limits__struct.h"
#include "origin_msgs/msg/detail/longitudal_velocity_limits__functions.h"
#include "origin_msgs/msg/detail/longitudal_velocity_limits__type_support.h"

#endif  // ORIGIN_MSGS__MSG__LONGITUDAL_VELOCITY_LIMITS_H_
