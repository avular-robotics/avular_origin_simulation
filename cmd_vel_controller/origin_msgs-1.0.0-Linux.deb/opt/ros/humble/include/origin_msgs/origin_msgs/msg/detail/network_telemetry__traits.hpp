// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__TRAITS_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "origin_msgs/msg/detail/network_telemetry__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace origin_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const NetworkTelemetry & msg,
  std::ostream & out)
{
  out << "{";
  // member: cellular_strength
  {
    out << "cellular_strength: ";
    rosidl_generator_traits::value_to_yaml(msg.cellular_strength, out);
    out << ", ";
  }

  // member: cellular_operator
  {
    out << "cellular_operator: ";
    rosidl_generator_traits::value_to_yaml(msg.cellular_operator, out);
    out << ", ";
  }

  // member: wifi_strength
  {
    out << "wifi_strength: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_strength, out);
    out << ", ";
  }

  // member: wifi_ssid
  {
    out << "wifi_ssid: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_ssid, out);
    out << ", ";
  }

  // member: wifi_ip
  {
    out << "wifi_ip: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_ip, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const NetworkTelemetry & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: cellular_strength
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cellular_strength: ";
    rosidl_generator_traits::value_to_yaml(msg.cellular_strength, out);
    out << "\n";
  }

  // member: cellular_operator
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cellular_operator: ";
    rosidl_generator_traits::value_to_yaml(msg.cellular_operator, out);
    out << "\n";
  }

  // member: wifi_strength
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wifi_strength: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_strength, out);
    out << "\n";
  }

  // member: wifi_ssid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wifi_ssid: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_ssid, out);
    out << "\n";
  }

  // member: wifi_ip
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wifi_ip: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_ip, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const NetworkTelemetry & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace origin_msgs

namespace rosidl_generator_traits
{

[[deprecated("use origin_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const origin_msgs::msg::NetworkTelemetry & msg,
  std::ostream & out, size_t indentation = 0)
{
  origin_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use origin_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const origin_msgs::msg::NetworkTelemetry & msg)
{
  return origin_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<origin_msgs::msg::NetworkTelemetry>()
{
  return "origin_msgs::msg::NetworkTelemetry";
}

template<>
inline const char * name<origin_msgs::msg::NetworkTelemetry>()
{
  return "origin_msgs/msg/NetworkTelemetry";
}

template<>
struct has_fixed_size<origin_msgs::msg::NetworkTelemetry>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<origin_msgs::msg::NetworkTelemetry>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<origin_msgs::msg::NetworkTelemetry>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__TRAITS_HPP_
