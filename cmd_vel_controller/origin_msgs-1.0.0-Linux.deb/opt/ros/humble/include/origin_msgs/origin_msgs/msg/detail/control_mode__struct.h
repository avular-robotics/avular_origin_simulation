// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/ControlMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__CONTROL_MODE__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__CONTROL_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'NONE'.
/**
  * Constants
  * If other modes are desired, they should be added below.
  * Node specific modes (0X)
  * No active control
 */
enum
{
  origin_msgs__msg__ControlMode__NONE = 0
};

/// Constant 'MANUAL'.
/**
  * Manual control modes (1X)
 */
enum
{
  origin_msgs__msg__ControlMode__MANUAL = 10
};

/// Constant 'TELEOPS'.
enum
{
  origin_msgs__msg__ControlMode__TELEOPS = 11
};

/// Constant 'MANUAL_MAPPING'.
enum
{
  origin_msgs__msg__ControlMode__MANUAL_MAPPING = 12
};

/// Constant 'AUTOPILOT'.
/**
  * Autonomous control modes (2X)
 */
enum
{
  origin_msgs__msg__ControlMode__AUTOPILOT = 20
};

/// Constant 'DOCKING'.
enum
{
  origin_msgs__msg__ControlMode__DOCKING = 21
};

/// Constant 'USER'.
/**
  * User control modes (3X)
 */
enum
{
  origin_msgs__msg__ControlMode__USER = 30
};

/// Struct defined in msg/ControlMode in the package origin_msgs.
/**
  * This message is used to communicate a control mode for the robot. 
  * It represents the desired or current control source being forwarded to the robot.
 */
typedef struct origin_msgs__msg__ControlMode
{
  /// Actual mode
  uint8_t mode;
} origin_msgs__msg__ControlMode;

// Struct for a sequence of origin_msgs__msg__ControlMode.
typedef struct origin_msgs__msg__ControlMode__Sequence
{
  origin_msgs__msg__ControlMode * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__ControlMode__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__CONTROL_MODE__STRUCT_H_
