// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:msg/InitialHeading.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__INITIAL_HEADING_H_
#define ORIGIN_MSGS__MSG__INITIAL_HEADING_H_

#include "origin_msgs/msg/detail/initial_heading__struct.h"
#include "origin_msgs/msg/detail/initial_heading__functions.h"
#include "origin_msgs/msg/detail/initial_heading__type_support.h"

#endif  // ORIGIN_MSGS__MSG__INITIAL_HEADING_H_
