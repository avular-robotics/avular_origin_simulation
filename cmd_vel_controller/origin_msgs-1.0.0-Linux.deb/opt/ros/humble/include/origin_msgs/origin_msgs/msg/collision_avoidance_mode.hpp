// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_HPP_
#define ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_HPP_

#include "origin_msgs/msg/detail/collision_avoidance_mode__struct.hpp"
#include "origin_msgs/msg/detail/collision_avoidance_mode__builder.hpp"
#include "origin_msgs/msg/detail/collision_avoidance_mode__traits.hpp"

#endif  // ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_HPP_
