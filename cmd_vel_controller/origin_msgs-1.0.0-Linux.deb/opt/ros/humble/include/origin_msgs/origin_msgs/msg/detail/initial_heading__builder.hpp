// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/InitialHeading.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/initial_heading__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_InitialHeading_initial_heading_rads
{
public:
  Init_InitialHeading_initial_heading_rads()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::origin_msgs::msg::InitialHeading initial_heading_rads(::origin_msgs::msg::InitialHeading::_initial_heading_rads_type arg)
  {
    msg_.initial_heading_rads = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::InitialHeading msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::InitialHeading>()
{
  return origin_msgs::msg::builder::Init_InitialHeading_initial_heading_rads();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__BUILDER_HPP_
