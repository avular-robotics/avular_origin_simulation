// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'CELLULAR_STRENGTH_EXCELLENT'.
/**
  * >= -70dBm
 */
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_EXCELLENT = 4
};

/// Constant 'CELLULAR_STRENGTH_GOOD'.
/**
  * -70dBm to -85dBm
 */
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_GOOD = 3
};

/// Constant 'CELLULAR_STRENGTH_FAIR'.
/**
  * -86dBm to -100dBm
 */
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_FAIR = 2
};

/// Constant 'CELLULAR_STRENGTH_POOR'.
/**
  * < -100dBm
 */
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_POOR = 1
};

/// Constant 'CELLULAR_STRENGTH_DISCONNECTED'.
/**
  * -110dBm
 */
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_DISCONNECTED = 0
};

/// Constant 'CELLULAR_STRENGTH_UNKNOWN'.
enum
{
  origin_msgs__msg__NetworkTelemetry__CELLULAR_STRENGTH_UNKNOWN = -1
};

/// Constant 'WIFI_STRENGTH_EXCELLENT'.
enum
{
  origin_msgs__msg__NetworkTelemetry__WIFI_STRENGTH_EXCELLENT = 3
};

/// Constant 'WIFI_STRENGTH_FAIR'.
enum
{
  origin_msgs__msg__NetworkTelemetry__WIFI_STRENGTH_FAIR = 2
};

/// Constant 'WIFI_STRENGTH_POOR'.
enum
{
  origin_msgs__msg__NetworkTelemetry__WIFI_STRENGTH_POOR = 1
};

/// Constant 'WIFI_STRENGTH_DISCONNECTED'.
enum
{
  origin_msgs__msg__NetworkTelemetry__WIFI_STRENGTH_DISCONNECTED = 0
};

/// Constant 'WIFI_STRENGTH_UNKNOWN'.
enum
{
  origin_msgs__msg__NetworkTelemetry__WIFI_STRENGTH_UNKNOWN = -1
};

// Include directives for member types
// Member 'cellular_operator'
// Member 'wifi_ssid'
// Member 'wifi_ip'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/NetworkTelemetry in the package origin_msgs.
/**
  * Indication of signal strength
  * Following the table listed on the following website: https://wiki.teltonika-networks.com/view/Mobile_Signal_Strength_Recommendations
 */
typedef struct origin_msgs__msg__NetworkTelemetry
{
  int8_t cellular_strength;
  rosidl_runtime_c__String cellular_operator;
  int8_t wifi_strength;
  rosidl_runtime_c__String wifi_ssid;
  rosidl_runtime_c__String wifi_ip;
} origin_msgs__msg__NetworkTelemetry;

// Struct for a sequence of origin_msgs__msg__NetworkTelemetry.
typedef struct origin_msgs__msg__NetworkTelemetry__Sequence
{
  origin_msgs__msg__NetworkTelemetry * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__NetworkTelemetry__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_H_
