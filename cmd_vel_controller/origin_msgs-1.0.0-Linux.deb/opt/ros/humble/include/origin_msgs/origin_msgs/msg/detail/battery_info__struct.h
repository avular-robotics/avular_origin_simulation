// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/BatteryInfo.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/BatteryInfo in the package origin_msgs.
/**
  * This message includes information on the state of the Origin's battery
 */
typedef struct origin_msgs__msg__BatteryInfo
{
  /// Battery voltage in V
  float voltage;
  /// % of charge remaining
  uint8_t state_of_charge;
} origin_msgs__msg__BatteryInfo;

// Struct for a sequence of origin_msgs__msg__BatteryInfo.
typedef struct origin_msgs__msg__BatteryInfo__Sequence
{
  origin_msgs__msg__BatteryInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__BatteryInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__STRUCT_H_
