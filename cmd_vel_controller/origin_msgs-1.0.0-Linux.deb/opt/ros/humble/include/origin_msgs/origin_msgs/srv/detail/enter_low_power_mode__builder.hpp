// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__BUILDER_HPP_
#define ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/srv/detail/enter_low_power_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace srv
{

namespace builder
{

class Init_EnterLowPowerMode_Request_wake_up_time
{
public:
  explicit Init_EnterLowPowerMode_Request_wake_up_time(::origin_msgs::srv::EnterLowPowerMode_Request & msg)
  : msg_(msg)
  {}
  ::origin_msgs::srv::EnterLowPowerMode_Request wake_up_time(::origin_msgs::srv::EnterLowPowerMode_Request::_wake_up_time_type arg)
  {
    msg_.wake_up_time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::srv::EnterLowPowerMode_Request msg_;
};

class Init_EnterLowPowerMode_Request_schedule_wakeup
{
public:
  Init_EnterLowPowerMode_Request_schedule_wakeup()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EnterLowPowerMode_Request_wake_up_time schedule_wakeup(::origin_msgs::srv::EnterLowPowerMode_Request::_schedule_wakeup_type arg)
  {
    msg_.schedule_wakeup = std::move(arg);
    return Init_EnterLowPowerMode_Request_wake_up_time(msg_);
  }

private:
  ::origin_msgs::srv::EnterLowPowerMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::srv::EnterLowPowerMode_Request>()
{
  return origin_msgs::srv::builder::Init_EnterLowPowerMode_Request_schedule_wakeup();
}

}  // namespace origin_msgs


namespace origin_msgs
{

namespace srv
{

namespace builder
{

class Init_EnterLowPowerMode_Response_return_code
{
public:
  Init_EnterLowPowerMode_Response_return_code()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::origin_msgs::srv::EnterLowPowerMode_Response return_code(::origin_msgs::srv::EnterLowPowerMode_Response::_return_code_type arg)
  {
    msg_.return_code = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::srv::EnterLowPowerMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::srv::EnterLowPowerMode_Response>()
{
  return origin_msgs::srv::builder::Init_EnterLowPowerMode_Response_return_code();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__BUILDER_HPP_
