// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice
#include "origin_msgs/msg/detail/network_telemetry__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `cellular_operator`
// Member `wifi_ssid`
// Member `wifi_ip`
#include "rosidl_runtime_c/string_functions.h"

bool
origin_msgs__msg__NetworkTelemetry__init(origin_msgs__msg__NetworkTelemetry * msg)
{
  if (!msg) {
    return false;
  }
  // cellular_strength
  // cellular_operator
  if (!rosidl_runtime_c__String__init(&msg->cellular_operator)) {
    origin_msgs__msg__NetworkTelemetry__fini(msg);
    return false;
  }
  // wifi_strength
  // wifi_ssid
  if (!rosidl_runtime_c__String__init(&msg->wifi_ssid)) {
    origin_msgs__msg__NetworkTelemetry__fini(msg);
    return false;
  }
  // wifi_ip
  if (!rosidl_runtime_c__String__init(&msg->wifi_ip)) {
    origin_msgs__msg__NetworkTelemetry__fini(msg);
    return false;
  }
  return true;
}

void
origin_msgs__msg__NetworkTelemetry__fini(origin_msgs__msg__NetworkTelemetry * msg)
{
  if (!msg) {
    return;
  }
  // cellular_strength
  // cellular_operator
  rosidl_runtime_c__String__fini(&msg->cellular_operator);
  // wifi_strength
  // wifi_ssid
  rosidl_runtime_c__String__fini(&msg->wifi_ssid);
  // wifi_ip
  rosidl_runtime_c__String__fini(&msg->wifi_ip);
}

bool
origin_msgs__msg__NetworkTelemetry__are_equal(const origin_msgs__msg__NetworkTelemetry * lhs, const origin_msgs__msg__NetworkTelemetry * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // cellular_strength
  if (lhs->cellular_strength != rhs->cellular_strength) {
    return false;
  }
  // cellular_operator
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cellular_operator), &(rhs->cellular_operator)))
  {
    return false;
  }
  // wifi_strength
  if (lhs->wifi_strength != rhs->wifi_strength) {
    return false;
  }
  // wifi_ssid
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->wifi_ssid), &(rhs->wifi_ssid)))
  {
    return false;
  }
  // wifi_ip
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->wifi_ip), &(rhs->wifi_ip)))
  {
    return false;
  }
  return true;
}

bool
origin_msgs__msg__NetworkTelemetry__copy(
  const origin_msgs__msg__NetworkTelemetry * input,
  origin_msgs__msg__NetworkTelemetry * output)
{
  if (!input || !output) {
    return false;
  }
  // cellular_strength
  output->cellular_strength = input->cellular_strength;
  // cellular_operator
  if (!rosidl_runtime_c__String__copy(
      &(input->cellular_operator), &(output->cellular_operator)))
  {
    return false;
  }
  // wifi_strength
  output->wifi_strength = input->wifi_strength;
  // wifi_ssid
  if (!rosidl_runtime_c__String__copy(
      &(input->wifi_ssid), &(output->wifi_ssid)))
  {
    return false;
  }
  // wifi_ip
  if (!rosidl_runtime_c__String__copy(
      &(input->wifi_ip), &(output->wifi_ip)))
  {
    return false;
  }
  return true;
}

origin_msgs__msg__NetworkTelemetry *
origin_msgs__msg__NetworkTelemetry__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  origin_msgs__msg__NetworkTelemetry * msg = (origin_msgs__msg__NetworkTelemetry *)allocator.allocate(sizeof(origin_msgs__msg__NetworkTelemetry), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(origin_msgs__msg__NetworkTelemetry));
  bool success = origin_msgs__msg__NetworkTelemetry__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
origin_msgs__msg__NetworkTelemetry__destroy(origin_msgs__msg__NetworkTelemetry * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    origin_msgs__msg__NetworkTelemetry__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
origin_msgs__msg__NetworkTelemetry__Sequence__init(origin_msgs__msg__NetworkTelemetry__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  origin_msgs__msg__NetworkTelemetry * data = NULL;

  if (size) {
    data = (origin_msgs__msg__NetworkTelemetry *)allocator.zero_allocate(size, sizeof(origin_msgs__msg__NetworkTelemetry), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = origin_msgs__msg__NetworkTelemetry__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        origin_msgs__msg__NetworkTelemetry__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
origin_msgs__msg__NetworkTelemetry__Sequence__fini(origin_msgs__msg__NetworkTelemetry__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      origin_msgs__msg__NetworkTelemetry__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

origin_msgs__msg__NetworkTelemetry__Sequence *
origin_msgs__msg__NetworkTelemetry__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  origin_msgs__msg__NetworkTelemetry__Sequence * array = (origin_msgs__msg__NetworkTelemetry__Sequence *)allocator.allocate(sizeof(origin_msgs__msg__NetworkTelemetry__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = origin_msgs__msg__NetworkTelemetry__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
origin_msgs__msg__NetworkTelemetry__Sequence__destroy(origin_msgs__msg__NetworkTelemetry__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    origin_msgs__msg__NetworkTelemetry__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
origin_msgs__msg__NetworkTelemetry__Sequence__are_equal(const origin_msgs__msg__NetworkTelemetry__Sequence * lhs, const origin_msgs__msg__NetworkTelemetry__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!origin_msgs__msg__NetworkTelemetry__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
origin_msgs__msg__NetworkTelemetry__Sequence__copy(
  const origin_msgs__msg__NetworkTelemetry__Sequence * input,
  origin_msgs__msg__NetworkTelemetry__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(origin_msgs__msg__NetworkTelemetry);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    origin_msgs__msg__NetworkTelemetry * data =
      (origin_msgs__msg__NetworkTelemetry *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!origin_msgs__msg__NetworkTelemetry__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          origin_msgs__msg__NetworkTelemetry__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!origin_msgs__msg__NetworkTelemetry__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
