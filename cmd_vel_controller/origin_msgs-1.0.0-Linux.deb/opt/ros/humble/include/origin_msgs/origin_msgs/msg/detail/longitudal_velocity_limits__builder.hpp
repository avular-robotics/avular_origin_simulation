// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/LongitudalVelocityLimits.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/longitudal_velocity_limits__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_LongitudalVelocityLimits_max_backward_velocity
{
public:
  explicit Init_LongitudalVelocityLimits_max_backward_velocity(::origin_msgs::msg::LongitudalVelocityLimits & msg)
  : msg_(msg)
  {}
  ::origin_msgs::msg::LongitudalVelocityLimits max_backward_velocity(::origin_msgs::msg::LongitudalVelocityLimits::_max_backward_velocity_type arg)
  {
    msg_.max_backward_velocity = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::LongitudalVelocityLimits msg_;
};

class Init_LongitudalVelocityLimits_max_forward_velocity
{
public:
  Init_LongitudalVelocityLimits_max_forward_velocity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LongitudalVelocityLimits_max_backward_velocity max_forward_velocity(::origin_msgs::msg::LongitudalVelocityLimits::_max_forward_velocity_type arg)
  {
    msg_.max_forward_velocity = std::move(arg);
    return Init_LongitudalVelocityLimits_max_backward_velocity(msg_);
  }

private:
  ::origin_msgs::msg::LongitudalVelocityLimits msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::LongitudalVelocityLimits>()
{
  return origin_msgs::msg::builder::Init_LongitudalVelocityLimits_max_forward_velocity();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__BUILDER_HPP_
