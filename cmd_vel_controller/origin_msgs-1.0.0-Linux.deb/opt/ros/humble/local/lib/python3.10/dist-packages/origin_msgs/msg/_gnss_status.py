# generated from rosidl_generator_py/resource/_idl.py.em
# with input from origin_msgs:msg/GNSSStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_GNSSStatus(type):
    """Metaclass of message 'GNSSStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STATUS_NO_FIX': -1,
        'STATUS_2D_FIX': 0,
        'STATUS_3D_FIX': 1,
        'STATUS_RTK_FLOAT': 2,
        'STATUS_RTK_FIX': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('origin_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'origin_msgs.msg.GNSSStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__gnss_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__gnss_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__gnss_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__gnss_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__gnss_status

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STATUS_NO_FIX': cls.__constants['STATUS_NO_FIX'],
            'STATUS_2D_FIX': cls.__constants['STATUS_2D_FIX'],
            'STATUS_3D_FIX': cls.__constants['STATUS_3D_FIX'],
            'STATUS_RTK_FLOAT': cls.__constants['STATUS_RTK_FLOAT'],
            'STATUS_RTK_FIX': cls.__constants['STATUS_RTK_FIX'],
        }

    @property
    def STATUS_NO_FIX(self):
        """Message constant 'STATUS_NO_FIX'."""
        return Metaclass_GNSSStatus.__constants['STATUS_NO_FIX']

    @property
    def STATUS_2D_FIX(self):
        """Message constant 'STATUS_2D_FIX'."""
        return Metaclass_GNSSStatus.__constants['STATUS_2D_FIX']

    @property
    def STATUS_3D_FIX(self):
        """Message constant 'STATUS_3D_FIX'."""
        return Metaclass_GNSSStatus.__constants['STATUS_3D_FIX']

    @property
    def STATUS_RTK_FLOAT(self):
        """Message constant 'STATUS_RTK_FLOAT'."""
        return Metaclass_GNSSStatus.__constants['STATUS_RTK_FLOAT']

    @property
    def STATUS_RTK_FIX(self):
        """Message constant 'STATUS_RTK_FIX'."""
        return Metaclass_GNSSStatus.__constants['STATUS_RTK_FIX']


class GNSSStatus(metaclass=Metaclass_GNSSStatus):
    """
    Message class 'GNSSStatus'.

    Constants:
      STATUS_NO_FIX
      STATUS_2D_FIX
      STATUS_3D_FIX
      STATUS_RTK_FLOAT
      STATUS_RTK_FIX
    """

    __slots__ = [
        '_header',
        '_status',
        '_horizontal_position_accuracy',
        '_vertical_position_accuracy',
        '_satellites_visible',
        '_satellites_used',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'status': 'int8',
        'horizontal_position_accuracy': 'float',
        'vertical_position_accuracy': 'float',
        'satellites_visible': 'uint8',
        'satellites_used': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.status = kwargs.get('status', int())
        self.horizontal_position_accuracy = kwargs.get('horizontal_position_accuracy', float())
        self.vertical_position_accuracy = kwargs.get('vertical_position_accuracy', float())
        self.satellites_visible = kwargs.get('satellites_visible', int())
        self.satellites_used = kwargs.get('satellites_used', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.status != other.status:
            return False
        if self.horizontal_position_accuracy != other.horizontal_position_accuracy:
            return False
        if self.vertical_position_accuracy != other.vertical_position_accuracy:
            return False
        if self.satellites_visible != other.satellites_visible:
            return False
        if self.satellites_used != other.satellites_used:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'status' field must be an integer in [-128, 127]"
        self._status = value

    @builtins.property
    def horizontal_position_accuracy(self):
        """Message field 'horizontal_position_accuracy'."""
        return self._horizontal_position_accuracy

    @horizontal_position_accuracy.setter
    def horizontal_position_accuracy(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'horizontal_position_accuracy' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'horizontal_position_accuracy' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._horizontal_position_accuracy = value

    @builtins.property
    def vertical_position_accuracy(self):
        """Message field 'vertical_position_accuracy'."""
        return self._vertical_position_accuracy

    @vertical_position_accuracy.setter
    def vertical_position_accuracy(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'vertical_position_accuracy' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'vertical_position_accuracy' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._vertical_position_accuracy = value

    @builtins.property
    def satellites_visible(self):
        """Message field 'satellites_visible'."""
        return self._satellites_visible

    @satellites_visible.setter
    def satellites_visible(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'satellites_visible' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'satellites_visible' field must be an unsigned integer in [0, 255]"
        self._satellites_visible = value

    @builtins.property
    def satellites_used(self):
        """Message field 'satellites_used'."""
        return self._satellites_used

    @satellites_used.setter
    def satellites_used(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'satellites_used' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'satellites_used' field must be an unsigned integer in [0, 255]"
        self._satellites_used = value
