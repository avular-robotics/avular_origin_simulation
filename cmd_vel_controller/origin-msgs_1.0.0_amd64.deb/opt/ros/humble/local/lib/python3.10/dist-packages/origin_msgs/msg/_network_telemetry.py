# generated from rosidl_generator_py/resource/_idl.py.em
# with input from origin_msgs:msg/NetworkTelemetry.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_NetworkTelemetry(type):
    """Metaclass of message 'NetworkTelemetry'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'CELLULAR_STRENGTH_EXCELLENT': 4,
        'CELLULAR_STRENGTH_GOOD': 3,
        'CELLULAR_STRENGTH_FAIR': 2,
        'CELLULAR_STRENGTH_POOR': 1,
        'CELLULAR_STRENGTH_DISCONNECTED': 0,
        'CELLULAR_STRENGTH_UNKNOWN': -1,
        'WIFI_STRENGTH_EXCELLENT': 3,
        'WIFI_STRENGTH_FAIR': 2,
        'WIFI_STRENGTH_POOR': 1,
        'WIFI_STRENGTH_DISCONNECTED': 0,
        'WIFI_STRENGTH_UNKNOWN': -1,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('origin_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'origin_msgs.msg.NetworkTelemetry')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__network_telemetry
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__network_telemetry
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__network_telemetry
            cls._TYPE_SUPPORT = module.type_support_msg__msg__network_telemetry
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__network_telemetry

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'CELLULAR_STRENGTH_EXCELLENT': cls.__constants['CELLULAR_STRENGTH_EXCELLENT'],
            'CELLULAR_STRENGTH_GOOD': cls.__constants['CELLULAR_STRENGTH_GOOD'],
            'CELLULAR_STRENGTH_FAIR': cls.__constants['CELLULAR_STRENGTH_FAIR'],
            'CELLULAR_STRENGTH_POOR': cls.__constants['CELLULAR_STRENGTH_POOR'],
            'CELLULAR_STRENGTH_DISCONNECTED': cls.__constants['CELLULAR_STRENGTH_DISCONNECTED'],
            'CELLULAR_STRENGTH_UNKNOWN': cls.__constants['CELLULAR_STRENGTH_UNKNOWN'],
            'WIFI_STRENGTH_EXCELLENT': cls.__constants['WIFI_STRENGTH_EXCELLENT'],
            'WIFI_STRENGTH_FAIR': cls.__constants['WIFI_STRENGTH_FAIR'],
            'WIFI_STRENGTH_POOR': cls.__constants['WIFI_STRENGTH_POOR'],
            'WIFI_STRENGTH_DISCONNECTED': cls.__constants['WIFI_STRENGTH_DISCONNECTED'],
            'WIFI_STRENGTH_UNKNOWN': cls.__constants['WIFI_STRENGTH_UNKNOWN'],
        }

    @property
    def CELLULAR_STRENGTH_EXCELLENT(self):
        """Message constant 'CELLULAR_STRENGTH_EXCELLENT'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_EXCELLENT']

    @property
    def CELLULAR_STRENGTH_GOOD(self):
        """Message constant 'CELLULAR_STRENGTH_GOOD'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_GOOD']

    @property
    def CELLULAR_STRENGTH_FAIR(self):
        """Message constant 'CELLULAR_STRENGTH_FAIR'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_FAIR']

    @property
    def CELLULAR_STRENGTH_POOR(self):
        """Message constant 'CELLULAR_STRENGTH_POOR'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_POOR']

    @property
    def CELLULAR_STRENGTH_DISCONNECTED(self):
        """Message constant 'CELLULAR_STRENGTH_DISCONNECTED'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_DISCONNECTED']

    @property
    def CELLULAR_STRENGTH_UNKNOWN(self):
        """Message constant 'CELLULAR_STRENGTH_UNKNOWN'."""
        return Metaclass_NetworkTelemetry.__constants['CELLULAR_STRENGTH_UNKNOWN']

    @property
    def WIFI_STRENGTH_EXCELLENT(self):
        """Message constant 'WIFI_STRENGTH_EXCELLENT'."""
        return Metaclass_NetworkTelemetry.__constants['WIFI_STRENGTH_EXCELLENT']

    @property
    def WIFI_STRENGTH_FAIR(self):
        """Message constant 'WIFI_STRENGTH_FAIR'."""
        return Metaclass_NetworkTelemetry.__constants['WIFI_STRENGTH_FAIR']

    @property
    def WIFI_STRENGTH_POOR(self):
        """Message constant 'WIFI_STRENGTH_POOR'."""
        return Metaclass_NetworkTelemetry.__constants['WIFI_STRENGTH_POOR']

    @property
    def WIFI_STRENGTH_DISCONNECTED(self):
        """Message constant 'WIFI_STRENGTH_DISCONNECTED'."""
        return Metaclass_NetworkTelemetry.__constants['WIFI_STRENGTH_DISCONNECTED']

    @property
    def WIFI_STRENGTH_UNKNOWN(self):
        """Message constant 'WIFI_STRENGTH_UNKNOWN'."""
        return Metaclass_NetworkTelemetry.__constants['WIFI_STRENGTH_UNKNOWN']


class NetworkTelemetry(metaclass=Metaclass_NetworkTelemetry):
    """
    Message class 'NetworkTelemetry'.

    Constants:
      CELLULAR_STRENGTH_EXCELLENT
      CELLULAR_STRENGTH_GOOD
      CELLULAR_STRENGTH_FAIR
      CELLULAR_STRENGTH_POOR
      CELLULAR_STRENGTH_DISCONNECTED
      CELLULAR_STRENGTH_UNKNOWN
      WIFI_STRENGTH_EXCELLENT
      WIFI_STRENGTH_FAIR
      WIFI_STRENGTH_POOR
      WIFI_STRENGTH_DISCONNECTED
      WIFI_STRENGTH_UNKNOWN
    """

    __slots__ = [
        '_cellular_strength',
        '_cellular_operator',
        '_wifi_strength',
        '_wifi_ssid',
        '_wifi_ip',
    ]

    _fields_and_field_types = {
        'cellular_strength': 'int8',
        'cellular_operator': 'string',
        'wifi_strength': 'int8',
        'wifi_ssid': 'string',
        'wifi_ip': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.cellular_strength = kwargs.get('cellular_strength', int())
        self.cellular_operator = kwargs.get('cellular_operator', str())
        self.wifi_strength = kwargs.get('wifi_strength', int())
        self.wifi_ssid = kwargs.get('wifi_ssid', str())
        self.wifi_ip = kwargs.get('wifi_ip', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.cellular_strength != other.cellular_strength:
            return False
        if self.cellular_operator != other.cellular_operator:
            return False
        if self.wifi_strength != other.wifi_strength:
            return False
        if self.wifi_ssid != other.wifi_ssid:
            return False
        if self.wifi_ip != other.wifi_ip:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def cellular_strength(self):
        """Message field 'cellular_strength'."""
        return self._cellular_strength

    @cellular_strength.setter
    def cellular_strength(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cellular_strength' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'cellular_strength' field must be an integer in [-128, 127]"
        self._cellular_strength = value

    @builtins.property
    def cellular_operator(self):
        """Message field 'cellular_operator'."""
        return self._cellular_operator

    @cellular_operator.setter
    def cellular_operator(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'cellular_operator' field must be of type 'str'"
        self._cellular_operator = value

    @builtins.property
    def wifi_strength(self):
        """Message field 'wifi_strength'."""
        return self._wifi_strength

    @wifi_strength.setter
    def wifi_strength(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'wifi_strength' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'wifi_strength' field must be an integer in [-128, 127]"
        self._wifi_strength = value

    @builtins.property
    def wifi_ssid(self):
        """Message field 'wifi_ssid'."""
        return self._wifi_ssid

    @wifi_ssid.setter
    def wifi_ssid(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'wifi_ssid' field must be of type 'str'"
        self._wifi_ssid = value

    @builtins.property
    def wifi_ip(self):
        """Message field 'wifi_ip'."""
        return self._wifi_ip

    @wifi_ip.setter
    def wifi_ip(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'wifi_ip' field must be of type 'str'"
        self._wifi_ip = value
