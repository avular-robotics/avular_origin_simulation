# generated from rosidl_generator_py/resource/_idl.py.em
# with input from origin_msgs:srv/EnterLowPowerMode.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_EnterLowPowerMode_Request(type):
    """Metaclass of message 'EnterLowPowerMode_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('origin_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'origin_msgs.srv.EnterLowPowerMode_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__enter_low_power_mode__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__enter_low_power_mode__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__enter_low_power_mode__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__enter_low_power_mode__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__enter_low_power_mode__request

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class EnterLowPowerMode_Request(metaclass=Metaclass_EnterLowPowerMode_Request):
    """Message class 'EnterLowPowerMode_Request'."""

    __slots__ = [
        '_schedule_wakeup',
        '_wake_up_time',
    ]

    _fields_and_field_types = {
        'schedule_wakeup': 'boolean',
        'wake_up_time': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.schedule_wakeup = kwargs.get('schedule_wakeup', bool())
        from builtin_interfaces.msg import Time
        self.wake_up_time = kwargs.get('wake_up_time', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.schedule_wakeup != other.schedule_wakeup:
            return False
        if self.wake_up_time != other.wake_up_time:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def schedule_wakeup(self):
        """Message field 'schedule_wakeup'."""
        return self._schedule_wakeup

    @schedule_wakeup.setter
    def schedule_wakeup(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'schedule_wakeup' field must be of type 'bool'"
        self._schedule_wakeup = value

    @builtins.property
    def wake_up_time(self):
        """Message field 'wake_up_time'."""
        return self._wake_up_time

    @wake_up_time.setter
    def wake_up_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'wake_up_time' field must be a sub message of type 'Time'"
        self._wake_up_time = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_EnterLowPowerMode_Response(type):
    """Metaclass of message 'EnterLowPowerMode_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'ERROR_NONE': 0,
        'ERROR_REJECTED': 1,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('origin_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'origin_msgs.srv.EnterLowPowerMode_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__enter_low_power_mode__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__enter_low_power_mode__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__enter_low_power_mode__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__enter_low_power_mode__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__enter_low_power_mode__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'ERROR_NONE': cls.__constants['ERROR_NONE'],
            'ERROR_REJECTED': cls.__constants['ERROR_REJECTED'],
        }

    @property
    def ERROR_NONE(self):
        """Message constant 'ERROR_NONE'."""
        return Metaclass_EnterLowPowerMode_Response.__constants['ERROR_NONE']

    @property
    def ERROR_REJECTED(self):
        """Message constant 'ERROR_REJECTED'."""
        return Metaclass_EnterLowPowerMode_Response.__constants['ERROR_REJECTED']


class EnterLowPowerMode_Response(metaclass=Metaclass_EnterLowPowerMode_Response):
    """
    Message class 'EnterLowPowerMode_Response'.

    Constants:
      ERROR_NONE
      ERROR_REJECTED
    """

    __slots__ = [
        '_return_code',
    ]

    _fields_and_field_types = {
        'return_code': 'int8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.return_code = kwargs.get('return_code', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.return_code != other.return_code:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def return_code(self):
        """Message field 'return_code'."""
        return self._return_code

    @return_code.setter
    def return_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'return_code' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'return_code' field must be an integer in [-128, 127]"
        self._return_code = value


class Metaclass_EnterLowPowerMode(type):
    """Metaclass of service 'EnterLowPowerMode'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('origin_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'origin_msgs.srv.EnterLowPowerMode')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__enter_low_power_mode

            from origin_msgs.srv import _enter_low_power_mode
            if _enter_low_power_mode.Metaclass_EnterLowPowerMode_Request._TYPE_SUPPORT is None:
                _enter_low_power_mode.Metaclass_EnterLowPowerMode_Request.__import_type_support__()
            if _enter_low_power_mode.Metaclass_EnterLowPowerMode_Response._TYPE_SUPPORT is None:
                _enter_low_power_mode.Metaclass_EnterLowPowerMode_Response.__import_type_support__()


class EnterLowPowerMode(metaclass=Metaclass_EnterLowPowerMode):
    from origin_msgs.srv._enter_low_power_mode import EnterLowPowerMode_Request as Request
    from origin_msgs.srv._enter_low_power_mode import EnterLowPowerMode_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
