// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from origin_msgs:msg/GNSSStatus.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "origin_msgs/msg/detail/gnss_status__rosidl_typesupport_introspection_c.h"
#include "origin_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "origin_msgs/msg/detail/gnss_status__functions.h"
#include "origin_msgs/msg/detail/gnss_status__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  origin_msgs__msg__GNSSStatus__init(message_memory);
}

void origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_fini_function(void * message_memory)
{
  origin_msgs__msg__GNSSStatus__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, status),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "horizontal_position_accuracy",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, horizontal_position_accuracy),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vertical_position_accuracy",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, vertical_position_accuracy),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "satellites_visible",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, satellites_visible),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "satellites_used",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(origin_msgs__msg__GNSSStatus, satellites_used),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_members = {
  "origin_msgs__msg",  // message namespace
  "GNSSStatus",  // message name
  6,  // number of fields
  sizeof(origin_msgs__msg__GNSSStatus),
  origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_member_array,  // message members
  origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_type_support_handle = {
  0,
  &origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_origin_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, origin_msgs, msg, GNSSStatus)() {
  origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_type_support_handle.typesupport_identifier) {
    origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &origin_msgs__msg__GNSSStatus__rosidl_typesupport_introspection_c__GNSSStatus_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
