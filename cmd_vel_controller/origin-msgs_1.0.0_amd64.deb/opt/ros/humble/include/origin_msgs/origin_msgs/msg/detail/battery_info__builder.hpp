// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/BatteryInfo.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/battery_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_BatteryInfo_state_of_charge
{
public:
  explicit Init_BatteryInfo_state_of_charge(::origin_msgs::msg::BatteryInfo & msg)
  : msg_(msg)
  {}
  ::origin_msgs::msg::BatteryInfo state_of_charge(::origin_msgs::msg::BatteryInfo::_state_of_charge_type arg)
  {
    msg_.state_of_charge = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::BatteryInfo msg_;
};

class Init_BatteryInfo_voltage
{
public:
  Init_BatteryInfo_voltage()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BatteryInfo_state_of_charge voltage(::origin_msgs::msg::BatteryInfo::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_BatteryInfo_state_of_charge(msg_);
  }

private:
  ::origin_msgs::msg::BatteryInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::BatteryInfo>()
{
  return origin_msgs::msg::builder::Init_BatteryInfo_voltage();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__BATTERY_INFO__BUILDER_HPP_
