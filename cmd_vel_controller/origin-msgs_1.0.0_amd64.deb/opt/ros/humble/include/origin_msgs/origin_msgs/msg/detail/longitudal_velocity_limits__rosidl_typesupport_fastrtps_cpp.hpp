// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from origin_msgs:msg/LongitudalVelocityLimits.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "origin_msgs/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "origin_msgs/msg/detail/longitudal_velocity_limits__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace origin_msgs
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_origin_msgs
cdr_serialize(
  const origin_msgs::msg::LongitudalVelocityLimits & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_origin_msgs
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  origin_msgs::msg::LongitudalVelocityLimits & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_origin_msgs
get_serialized_size(
  const origin_msgs::msg::LongitudalVelocityLimits & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_origin_msgs
max_serialized_size_LongitudalVelocityLimits(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace origin_msgs

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_origin_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, origin_msgs, msg, LongitudalVelocityLimits)();

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
