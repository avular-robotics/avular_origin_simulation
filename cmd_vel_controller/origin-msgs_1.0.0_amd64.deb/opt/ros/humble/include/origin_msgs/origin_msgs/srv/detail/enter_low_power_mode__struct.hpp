// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from origin_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_HPP_
#define ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'wake_up_time'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Request __attribute__((deprecated))
#else
# define DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Request __declspec(deprecated)
#endif

namespace origin_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EnterLowPowerMode_Request_
{
  using Type = EnterLowPowerMode_Request_<ContainerAllocator>;

  explicit EnterLowPowerMode_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : wake_up_time(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->schedule_wakeup = false;
    }
  }

  explicit EnterLowPowerMode_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : wake_up_time(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->schedule_wakeup = false;
    }
  }

  // field types and members
  using _schedule_wakeup_type =
    bool;
  _schedule_wakeup_type schedule_wakeup;
  using _wake_up_time_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _wake_up_time_type wake_up_time;

  // setters for named parameter idiom
  Type & set__schedule_wakeup(
    const bool & _arg)
  {
    this->schedule_wakeup = _arg;
    return *this;
  }
  Type & set__wake_up_time(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->wake_up_time = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Request
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Request
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EnterLowPowerMode_Request_ & other) const
  {
    if (this->schedule_wakeup != other.schedule_wakeup) {
      return false;
    }
    if (this->wake_up_time != other.wake_up_time) {
      return false;
    }
    return true;
  }
  bool operator!=(const EnterLowPowerMode_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EnterLowPowerMode_Request_

// alias to use template instance with default allocator
using EnterLowPowerMode_Request =
  origin_msgs::srv::EnterLowPowerMode_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace origin_msgs


#ifndef _WIN32
# define DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Response __attribute__((deprecated))
#else
# define DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Response __declspec(deprecated)
#endif

namespace origin_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EnterLowPowerMode_Response_
{
  using Type = EnterLowPowerMode_Response_<ContainerAllocator>;

  explicit EnterLowPowerMode_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->return_code = 0;
    }
  }

  explicit EnterLowPowerMode_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->return_code = 0;
    }
  }

  // field types and members
  using _return_code_type =
    int8_t;
  _return_code_type return_code;

  // setters for named parameter idiom
  Type & set__return_code(
    const int8_t & _arg)
  {
    this->return_code = _arg;
    return *this;
  }

  // constant declarations
  static constexpr int8_t ERROR_NONE =
    0;
  static constexpr int8_t ERROR_REJECTED =
    1;

  // pointer types
  using RawPtr =
    origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Response
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__origin_msgs__srv__EnterLowPowerMode_Response
    std::shared_ptr<origin_msgs::srv::EnterLowPowerMode_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EnterLowPowerMode_Response_ & other) const
  {
    if (this->return_code != other.return_code) {
      return false;
    }
    return true;
  }
  bool operator!=(const EnterLowPowerMode_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EnterLowPowerMode_Response_

// alias to use template instance with default allocator
using EnterLowPowerMode_Response =
  origin_msgs::srv::EnterLowPowerMode_Response_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t EnterLowPowerMode_Response_<ContainerAllocator>::ERROR_NONE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t EnterLowPowerMode_Response_<ContainerAllocator>::ERROR_REJECTED;
#endif  // __cplusplus < 201703L

}  // namespace srv

}  // namespace origin_msgs

namespace origin_msgs
{

namespace srv
{

struct EnterLowPowerMode
{
  using Request = origin_msgs::srv::EnterLowPowerMode_Request;
  using Response = origin_msgs::srv::EnterLowPowerMode_Response;
};

}  // namespace srv

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_HPP_
