// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/GNSSStatus.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/gnss_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_GNSSStatus_satellites_used
{
public:
  explicit Init_GNSSStatus_satellites_used(::origin_msgs::msg::GNSSStatus & msg)
  : msg_(msg)
  {}
  ::origin_msgs::msg::GNSSStatus satellites_used(::origin_msgs::msg::GNSSStatus::_satellites_used_type arg)
  {
    msg_.satellites_used = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

class Init_GNSSStatus_satellites_visible
{
public:
  explicit Init_GNSSStatus_satellites_visible(::origin_msgs::msg::GNSSStatus & msg)
  : msg_(msg)
  {}
  Init_GNSSStatus_satellites_used satellites_visible(::origin_msgs::msg::GNSSStatus::_satellites_visible_type arg)
  {
    msg_.satellites_visible = std::move(arg);
    return Init_GNSSStatus_satellites_used(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

class Init_GNSSStatus_vertical_position_accuracy
{
public:
  explicit Init_GNSSStatus_vertical_position_accuracy(::origin_msgs::msg::GNSSStatus & msg)
  : msg_(msg)
  {}
  Init_GNSSStatus_satellites_visible vertical_position_accuracy(::origin_msgs::msg::GNSSStatus::_vertical_position_accuracy_type arg)
  {
    msg_.vertical_position_accuracy = std::move(arg);
    return Init_GNSSStatus_satellites_visible(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

class Init_GNSSStatus_horizontal_position_accuracy
{
public:
  explicit Init_GNSSStatus_horizontal_position_accuracy(::origin_msgs::msg::GNSSStatus & msg)
  : msg_(msg)
  {}
  Init_GNSSStatus_vertical_position_accuracy horizontal_position_accuracy(::origin_msgs::msg::GNSSStatus::_horizontal_position_accuracy_type arg)
  {
    msg_.horizontal_position_accuracy = std::move(arg);
    return Init_GNSSStatus_vertical_position_accuracy(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

class Init_GNSSStatus_status
{
public:
  explicit Init_GNSSStatus_status(::origin_msgs::msg::GNSSStatus & msg)
  : msg_(msg)
  {}
  Init_GNSSStatus_horizontal_position_accuracy status(::origin_msgs::msg::GNSSStatus::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_GNSSStatus_horizontal_position_accuracy(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

class Init_GNSSStatus_header
{
public:
  Init_GNSSStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GNSSStatus_status header(::origin_msgs::msg::GNSSStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GNSSStatus_status(msg_);
  }

private:
  ::origin_msgs::msg::GNSSStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::GNSSStatus>()
{
  return origin_msgs::msg::builder::Init_GNSSStatus_header();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__BUILDER_HPP_
