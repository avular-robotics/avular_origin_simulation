// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/InitialHeading.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/InitialHeading in the package origin_msgs.
/**
  * The inital heading of the robot in radians
 */
typedef struct origin_msgs__msg__InitialHeading
{
  float initial_heading_rads;
} origin_msgs__msg__InitialHeading;

// Struct for a sequence of origin_msgs__msg__InitialHeading.
typedef struct origin_msgs__msg__InitialHeading__Sequence
{
  origin_msgs__msg__InitialHeading * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__InitialHeading__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__INITIAL_HEADING__STRUCT_H_
