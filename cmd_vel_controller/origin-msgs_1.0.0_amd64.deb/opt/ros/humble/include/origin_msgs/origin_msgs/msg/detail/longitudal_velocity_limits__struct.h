// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/LongitudalVelocityLimits.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/LongitudalVelocityLimits in the package origin_msgs.
/**
  * Longitudinal velocity limits in m/s as set by the safety supervisor.
  * These limits may be decreased when the ultrasonic sensors detect an
  * obstacle for example
 */
typedef struct origin_msgs__msg__LongitudalVelocityLimits
{
  float max_forward_velocity;
  float max_backward_velocity;
} origin_msgs__msg__LongitudalVelocityLimits;

// Struct for a sequence of origin_msgs__msg__LongitudalVelocityLimits.
typedef struct origin_msgs__msg__LongitudalVelocityLimits__Sequence
{
  origin_msgs__msg__LongitudalVelocityLimits * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__LongitudalVelocityLimits__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__LONGITUDAL_VELOCITY_LIMITS__STRUCT_H_
