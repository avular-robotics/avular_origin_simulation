// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:srv/ReturnControlMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__RETURN_CONTROL_MODE_H_
#define ORIGIN_MSGS__SRV__RETURN_CONTROL_MODE_H_

#include "origin_msgs/srv/detail/return_control_mode__struct.h"
#include "origin_msgs/srv/detail/return_control_mode__functions.h"
#include "origin_msgs/srv/detail/return_control_mode__type_support.h"

#endif  // ORIGIN_MSGS__SRV__RETURN_CONTROL_MODE_H_
