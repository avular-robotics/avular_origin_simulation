﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/GNSSStatus.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STATUS_NO_FIX'.
/**
  * GNSS fix type
  * Unable to fix position
 */
enum
{
  origin_msgs__msg__GNSSStatus__STATUS_NO_FIX = -1
};

/// Constant 'STATUS_2D_FIX'.
/**
  * 2D fix
 */
enum
{
  origin_msgs__msg__GNSSStatus__STATUS_2D_FIX = 0
};

/// Constant 'STATUS_3D_FIX'.
/**
  * 3D fix
 */
enum
{
  origin_msgs__msg__GNSSStatus__STATUS_3D_FIX = 1
};

/// Constant 'STATUS_RTK_FLOAT'.
/**
  * RTK with floating solution, the RTK algorithm hasn’t found an acceptable fix solution (yet)
 */
enum
{
  origin_msgs__msg__GNSSStatus__STATUS_RTK_FLOAT = 2
};

/// Constant 'STATUS_RTK_FIX'.
/**
  * RTK with fixed solution
 */
enum
{
  origin_msgs__msg__GNSSStatus__STATUS_RTK_FIX = 3
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/GNSSStatus in the package origin_msgs.
/**
  * GNSS status, a supplement to sensor_msgs/NavSatFix.
 */
typedef struct origin_msgs__msg__GNSSStatus
{
  std_msgs__msg__Header header;
  int8_t status;
  /// Uncertainty of measurement, 1-sigma confidence
  /// Horizontal position uncertainty (meters) expressed as a bivariate normal distribution, 1-sigma then corresponds to 39.4% confidence
  float horizontal_position_accuracy;
  /// Vertical position uncertainty (meters) expressed as a univariate normal distribution, 1-sigma then corresponds to 68% confidence
  float vertical_position_accuracy;
  /// Satellites visible
  /// Number of satellites visible
  uint8_t satellites_visible;
  /// Number of satellites used
  uint8_t satellites_used;
} origin_msgs__msg__GNSSStatus;

// Struct for a sequence of origin_msgs__msg__GNSSStatus.
typedef struct origin_msgs__msg__GNSSStatus__Sequence
{
  origin_msgs__msg__GNSSStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__GNSSStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_H_
