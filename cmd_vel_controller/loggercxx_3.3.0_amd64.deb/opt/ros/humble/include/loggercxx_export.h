
#ifndef LOGGERCXX_DLLAPI_H
#define LOGGERCXX_DLLAPI_H

#ifdef LOGGERCXX_STATIC_DEFINE
#  define LOGGERCXX_DLLAPI
#  define LOGGERCXX_NO_EXPORT
#else
#  ifndef LOGGERCXX_DLLAPI
#    ifdef loggercxx_EXPORTS
        /* We are building this library */
#      define LOGGERCXX_DLLAPI __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LOGGERCXX_DLLAPI __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LOGGERCXX_NO_EXPORT
#    define LOGGERCXX_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LOGGERCXX_DEPRECATED
#  define LOGGERCXX_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LOGGERCXX_DEPRECATED_EXPORT
#  define LOGGERCXX_DEPRECATED_EXPORT LOGGERCXX_DLLAPI LOGGERCXX_DEPRECATED
#endif

#ifndef LOGGERCXX_DEPRECATED_NO_EXPORT
#  define LOGGERCXX_DEPRECATED_NO_EXPORT LOGGERCXX_NO_EXPORT LOGGERCXX_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LOGGERCXX_NO_DEPRECATED
#    define LOGGERCXX_NO_DEPRECATED
#  endif
#endif

#endif /* LOGGERCXX_DLLAPI_H */
