// Copyright 2025 Avular Holding B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <chrono>

class Throttle {
public:
  template <typename Duration>
  Throttle(Duration interval)
      : interval_(
            std::chrono::duration_cast<std::chrono::milliseconds>(interval)),
        last_log_time_(std::chrono::steady_clock::now() - interval_) {}

  bool shouldLog() {
    auto now = std::chrono::steady_clock::now();
    if (now - last_log_time_ >= interval_) {
      last_log_time_ = now;
      return true;
    }
    return false;
  }

private:
  std::chrono::milliseconds interval_;
  std::chrono::steady_clock::time_point last_log_time_;
};