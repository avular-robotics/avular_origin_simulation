// Copyright 2024 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <limits>
#include <mutex>
#include <rclcpp/node_interfaces/node_parameters_interface.hpp>
#include <rclcpp/parameter_value.hpp>

namespace rclcpp_avular
{

/**
 * @brief This class creates a ros parameter, attaches a callback function to keep its value up to date, and allows to
 * set ranges, even for vector types. The actual (updated) parameter value can be extracted with the GetValue() method.
 *
 * @tparam T type of parameter.
 */
template <typename T>
class SimpleRosParameter
{
private:
  /**
   * @brief tool to check whether the template parameter is an vector or not.
   *
   * @tparam typename under test.
   */
  template <typename>
  struct is_vector : std::false_type
  {
  };

  /**
   * @brief tool to check whether the template parameter is an vector or not.
   *
   * @tparam typename under test.
   */
  template <typename U>
  struct is_vector<std::vector<U>> : std::true_type
  {
  };

  /**
   * @brief tool to check the underlying type of a template parameter. If the template parameter type is a trivial type,
   * the type is returned. If the template parameter is a vector, the value_type is returned.
   *
   * @tparam U
   */
  template <typename U>
  struct underlying_type
  {
    using value = U;
  };

  /**
   * @brief tool to check the underlying type of a template parameter. If the template parameter type is a trivial type,
   * the type is returned. If the template parameter is a vector, the value_type is returned.
   *
   * @tparam U
   */
  template <typename U>
  struct underlying_type<std::vector<U>>
  {
    using value = U;
  };

  using BaseType = underlying_type<T>::value;

public:
  /**
   * @brief Construct a new Simple Ros Parameter object and declare the corresponding ros parameter. If the parameter is
   * marked as being updatable, a callback function is attached such that it gets notified when the ros parameter is
   * updated.
   *
   * @param param_interface shared pointer to the node parameters interface (typically acquired by
   * `node_ptr->get_node_parameters_interface()`)
   * @param param_name name of the ros parameter to declare.
   * @param default_value the initial value of the parameter, if it is not defined by e.g. a config file.
   * @param updatable whether or not this parameter can be updated or is read-only.
   * @param description parameter description.
   * @throws a runtime error if the ros parameter is not within the specified range.
   */
  SimpleRosParameter(rclcpp::node_interfaces::NodeParametersInterface::SharedPtr param_interface,
                     const std::string& param_name, const T& default_value, const bool& updatable = true,
                     const std::string& description = "");

  /**
   * @brief Construct a new Simple Ros Parameter object and declare the corresponding ros parameter. If the parameter is
   * marked as being updatable, a callback function is attached such that it gets notified when the ros parameter is
   * updated.
   *
   * @param param_interface shared pointer to the node parameters interface (typically acquired by
   * `node_ptr->get_node_parameters_interface()`)
   * @param param_name name of the ros parameter to declare.
   * @param default_value the initial value of the parameter, if it is not defined by e.g. a config file.
   * @param updatable whether or not this parameter can be updated or is read-only.
   * @param description parameter description.
   * @param range the range of a parameter, only valid for integer, floating point, or vectors of integer or floating
   * point types. If a range is defined for other types, the range is ignored.
   * @param step_size the step size at which the parameter can be changed. Only valid for integer and floating point
   * types. For other types, the step size is ignored.
   * @throws a runtime error if the ros parameter is not within the specified range.
   */
  SimpleRosParameter(rclcpp::node_interfaces::NodeParametersInterface::SharedPtr param_interface,
                     const std::string& param_name, const T& default_value, const bool& updatable,
                     const std::string& description, const std::pair<BaseType, BaseType> range,
                     const BaseType step_size = BaseType());

  /**
   * @brief Destroy the Simple Ros Parameter object and removes the callback function from the parameter interface, if
   * there is one.
   *
   */
  ~SimpleRosParameter();

  /**
   * @brief Get the actual value of the (ros) parameter.
   *
   * @return T value of the parameter.
   */
  T GetValue();

private:
  /**
   * @brief Declares the ros parameter, if it has not yet been declared and checks whether the parameter is within the
   * range if a range is configured.
   *
   * @param default_value the initial value of the parameter, if it is not defined by e.g. a config file.
   * @param descriptor parameter description, used to configure the ros parameter.
   * @throws a runtime error when the parameter is not within the specified range.
   */
  void DeclareParameter(const T& default_value, const rcl_interfaces::msg::ParameterDescriptor& descriptor);

  /**
   * @brief Checks whether the parameter is within the range configured in _range. Only actually checks integer and
   * floating point types and vectors of integer and floating point types. For all other types it returns \c true.
   *
   * @param parameter Parameter to check whether its values are within range.
   * @return \c true if all values lie within the range specified in _range, \c false otherwise.
   */
  bool CheckBounds(const rclcpp::ParameterValue& parameter);

  /**
   * @brief Callback function that is attached to the parameter interface for parameters that are updatable. It is
   * called when a parameter is updated, and checks whether this update is valid. When not valid, the update is
   * rejected, when valid, the parameter value is updated.
   *
   * @param parameters vector of parameters that is being updated.
   * @return rcl_interfaces::msg::SetParametersResult parameters result that indicates whether all parameters were able
   * to be updated.
   */
  rcl_interfaces::msg::SetParametersResult UpdateParameterCallback(const std::vector<rclcpp::Parameter>& parameters);

  // Ros node parameter interface.
  rclcpp::node_interfaces::NodeParametersInterface::SharedPtr _param_interface;

  // Pointer to the parameter callback function.
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr _param_callback_function_handle;

  // Internal copy of the ros parameter.
  rclcpp::ParameterValue _param;

  // Ros parameter name.
  std::string _name;

  // Element range that integer and floating point types, and vectors of these types have to adhere to.
  std::pair<BaseType, BaseType> _element_range = {std::numeric_limits<BaseType>::lowest(),
                                                  std::numeric_limits<BaseType>::max()};

  // Mutex to prevent simultaneous reading and writing to the parameter.
  std::mutex _parameter_mutex;
};

template <typename T>
void SimpleRosParameter<T>::DeclareParameter(const T& default_value,
                                             const rcl_interfaces::msg::ParameterDescriptor& descriptor)
{
  // Check whether the ros parameter already exist, and declare it if this is not yet the case.
  if(!_param_interface->has_parameter(_name))
  {
    // Declare the ros parameter.
    const auto parameter =
        _param_interface->declare_parameter(_name, rclcpp::ParameterValue(default_value), descriptor);

    // Check if the ros parameter is within the specified range, throw an error if this is not the case.
    if(!CheckBounds(parameter))
    {
      const std::string err_msg = "Not all values in the parameter '" + _name + "' are within bounds";
      throw std::runtime_error(err_msg);
    }

    // Copy the value to the parameter.
    _param = parameter;
  }
  else
  {
    // If the parameter already exists, get the parameter as is.
    _param = _param_interface->get_parameter(_name).get_parameter_value();

    // Throw an error if the existing parameter type does not correspond to the desired parameter type.
    if(rclcpp::ParameterValue(default_value).get_type() != _param.get_type())
    {
      throw std::runtime_error("Parameter was already declared but type is not the same");
    }
  }

  // Add callback function if parameter is updatable.
  if(!descriptor.read_only)
  {
    _param_callback_function_handle = _param_interface->add_on_set_parameters_callback(
        std::bind(&SimpleRosParameter<T>::UpdateParameterCallback, std::ref(*this), std::placeholders::_1));
  }
}

template <typename T>
bool SimpleRosParameter<T>::CheckBounds(const rclcpp::ParameterValue& parameter)
{
  // If the type is a vector of floating point values, check if all elements are within the specified range.
  if constexpr(is_vector<T>::value && std::is_floating_point<BaseType>::value)
  {
    const auto& vector = parameter.get<rclcpp::ParameterType::PARAMETER_DOUBLE_ARRAY>();
    for(const auto& element : vector)
    {
      if(element < _element_range.first || element > _element_range.second)
      {
        return false;
      }
    }
  }

  // If the type is a vector of int, check if all elements are within the specified range.
  else if constexpr(is_vector<T>::value && std::is_same_v<BaseType, int>)
  {
    const auto& vector = parameter.get<rclcpp::ParameterType::PARAMETER_INTEGER_ARRAY>();
    for(const auto& element : vector)
      if(element < _element_range.first || element > _element_range.second)
      {
        return false;
      }
  }

  // If the type is a floating point type, check if its value is within the specified range.
  else if constexpr(std::is_floating_point<T>::value)
  {
    const auto& value = parameter.get<rclcpp::ParameterType::PARAMETER_DOUBLE>();
    if(value < _element_range.first || value > _element_range.second)
    {
      return false;
    }
  }

  // If the type is an int, check if its value is within the specified range.
  else if constexpr(std::is_same_v<T, int>)
  {
    const auto& value = parameter.get<rclcpp::ParameterType::PARAMETER_INTEGER>();
    if(value < _element_range.first || value > _element_range.second)
    {
      return false;
    }
  }

  // Default return value.
  return true;
}

template <typename T>
SimpleRosParameter<T>::SimpleRosParameter(rclcpp::node_interfaces::NodeParametersInterface::SharedPtr param_interface,
                                          const std::string& param_name, const T& default_value, const bool& updatable,
                                          const std::string& description)
    : _param_interface(param_interface), _name(param_name)
{
  // Create a parameter descriptor.
  rcl_interfaces::msg::ParameterDescriptor param_descriptor;
  param_descriptor.description = description;
  param_descriptor.read_only = !updatable;

  // Declare the ros parameter and attach a callback function.
  DeclareParameter(default_value, param_descriptor);
}

template <typename T>
SimpleRosParameter<T>::SimpleRosParameter(rclcpp::node_interfaces::NodeParametersInterface::SharedPtr param_interface,
                                          const std::string& param_name, const T& default_value, const bool& updatable,
                                          const std::string& description, const std::pair<BaseType, BaseType> range,
                                          const BaseType step_size)
    : _param_interface(param_interface), _name(param_name), _element_range(range)
{
  // Create a parameter descriptor.
  rcl_interfaces::msg::ParameterDescriptor param_descriptor;
  param_descriptor.description = description;
  param_descriptor.read_only = !updatable;
  if constexpr(std::is_same_v<BaseType, int>)
  {
    param_descriptor.integer_range.resize(1);
    param_descriptor.integer_range[0].from_value = range.first;
    param_descriptor.integer_range[0].to_value = range.second;
    param_descriptor.integer_range[0].step = step_size;
  }
  else if constexpr(std::is_floating_point<BaseType>::value)
  {
    param_descriptor.floating_point_range.resize(1);
    param_descriptor.floating_point_range[0].from_value = range.first;
    param_descriptor.floating_point_range[0].to_value = range.second;
    param_descriptor.floating_point_range[0].step = step_size;
  }

  // Declare the ros parameter and attach a callback function.
  DeclareParameter(default_value, param_descriptor);
}

template <typename T>
SimpleRosParameter<T>::~SimpleRosParameter()
{
  // Remove parameter callback.
  if(_param_callback_function_handle)
  {
    _param_interface->remove_on_set_parameters_callback(_param_callback_function_handle.get());
  }
}

template <typename T>
T SimpleRosParameter<T>::GetValue()
{
  std::lock_guard<std::mutex> lock(_parameter_mutex);
  if constexpr(std::is_same_v<T, bool>)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_BOOL>();
  }
  else if constexpr(std::is_integral<T>::value)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_INTEGER>();
  }
  else if constexpr(std::is_floating_point<T>::value)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_DOUBLE>();
  }
  else if constexpr(std::is_same_v<T, std::string>)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_STRING>();
  }
  else if constexpr(std::is_same_v<T, std::vector<uint8_t>>)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_BYTE_ARRAY>();
  }
  else if constexpr(std::is_same_v<T, std::vector<bool>>)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_BOOL_ARRAY>();
  }
  else if constexpr(std::is_same_v<T, std::vector<int>>)
  {
    const auto& vector = _param.get<rclcpp::ParameterType::PARAMETER_INTEGER_ARRAY>();
    return T(vector.begin(), vector.end());
  }
  else if constexpr(is_vector<T>::value && std::is_floating_point<BaseType>::value)
  {
    const auto& vector = _param.get<rclcpp::ParameterType::PARAMETER_DOUBLE_ARRAY>();
    return T(vector.begin(), vector.end());
  }
  else if constexpr(std::is_same_v<T, std::vector<std::string>>)
  {
    return _param.get<rclcpp::ParameterType::PARAMETER_STRING_ARRAY>();
  }
  throw std::runtime_error("Unknown parameter type!");
}

template <typename T>
rcl_interfaces::msg::SetParametersResult SimpleRosParameter<T>::UpdateParameterCallback(
    const std::vector<rclcpp::Parameter>& parameters)
{
  // Create default parameter result.
  rcl_interfaces::msg::SetParametersResult result;
  result.successful = true;

  // Check the list of parameters whether there is a parameter that corresponds to our parameter name.
  for(const auto& parameter : parameters)
  {
    if(parameter.get_name() == _name)
    {
      // Get the parameter value.
      rclcpp::ParameterValue parameter_value = parameter.get_parameter_value();

      // Check if the parameter is within the specified range, and reject the update if this is not the case.
      if(!CheckBounds(parameter_value))
      {
        result.successful = false;
        result.reason += "One of the elements in the array is out of bounds ";
        continue;
      }

      // Copy the parameter value.
      std::lock_guard<std::mutex> lock(_parameter_mutex);
      _param = parameter_value;
    }
  }
  return result;
}

}  // namespace rclcpp_avular
