// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <lifecycle_msgs/srv/change_state.hpp>
#include <lifecycle_msgs/srv/get_state.hpp>
#include <memory>

#include "rclcpp_avular/helper_service.hpp"
#include "rclcpp_avular/lifecycle_node.hpp"
#include "rclcpp_avular/node.hpp"
#include "rclcpp_avular/qos.hpp"

/**
 * @brief Generate transition name from the transition value
 *
 * @param transition transition value
 *
 * @note List obtained from https://docs.ros2.org/foxy/api/lifecycle_msgs/msg/Transition.html
 * @return std::string transition name
 */
static std::string TransitionName(std::uint8_t const transition)
{
  switch(transition)
  {
    case 0:
      return "Create";
    case 1:
      return "Configure";
    case 2:
      return "Cleanup";
    case 3:
      return "Activate";
    case 4:
      return "Deactivate";
    case 5:
      return "Unconfigured Shutdown";
    case 6:
      return "Inactive Shutdown";
    case 7:
      return "Activate Shutdown";
    case 8:
      return "Destroy";
  }
  return std::to_string(static_cast<int>(transition));
}

using NodeTransitionClientPtr = std::shared_ptr<rclcpp::Client<lifecycle_msgs::srv::ChangeState>>;
using NodeGetStateClientPtr = std::shared_ptr<rclcpp::Client<lifecycle_msgs::srv::GetState>>;

class SupervisedNode
{
public:
  SupervisedNode(rclcpp_avular::Node *const node, std::string const &name, std::chrono::seconds const &time_out,
                 std::string const &ns = "")
      : logger_(node->get_logger()), name_(name), time_out_(time_out)
  {
    std::string node_address = "";
    if(ns == "")
    {
      node_address = name;
    }
    else
    {
      node_address = ns + "/" + name;
    }
    client_transition_ = node->create_client<lifecycle_msgs::srv::ChangeState>(node_address + "/change_state");
    client_get_state_ = node->create_client<lifecycle_msgs::srv::GetState>(node_address + "/get_state");
  }

  SupervisedNode(std::shared_ptr<rclcpp::Node> const node, std::string const &name,
                 std::chrono::seconds const &time_out, std::string const &ns = "")
      : logger_(node->get_logger()), name_(name), time_out_(time_out)
  {
    std::string node_address = "";
    if(ns == "")
    {
      node_address = name;
    }
    else
    {
      node_address = ns + "/" + name;
    }
    client_transition_ = node->create_client<lifecycle_msgs::srv::ChangeState>(node_address + "/change_state");
    client_get_state_ = node->create_client<lifecycle_msgs::srv::GetState>(node_address + "/get_state");
  }

  SupervisedNode(rclcpp_avular::LifecycleNode *const node, std::string const &name,
                 std::chrono::seconds const &time_out, std::string const &ns = "")
      : logger_(node->get_logger()), name_(name), time_out_(time_out)
  {
    std::string node_address = "";
    if(ns == "")
    {
      node_address = name;
    }
    else
    {
      node_address = ns + "/" + name;
    }
    client_transition_ = node->create_client<lifecycle_msgs::srv::ChangeState>(node_address + "/change_state");
    client_get_state_ = node->create_client<lifecycle_msgs::srv::GetState>(node_address + "/get_state");
  }

  /** \brief Gets the current lifecycle state of the supervised node
   *
   * \returns on success: current state defined as lifecycle_msgs::msg::State
   * \returns on failure: lifecycle_msgs::msg::State::PRIMARY_STATE_UNKNOWN
   */
  std::uint8_t GetState()
  {
    auto request = std::make_shared<lifecycle_msgs::srv::GetState::Request>();

    auto response = rclcpp_avular::QueryService(client_get_state_, request, time_out_);
    if(response == std::nullopt)
    {
      RCLCPP_INFO_STREAM(get_logger(), "Could not reach node " << Name() << " to obtain state.");
      return lifecycle_msgs::msg::State::PRIMARY_STATE_UNKNOWN;
    }
    return (*response)->current_state.id;
  }

  /** @brief Tells the supervised node to apply a given transition
   *
   *  @param transition The desired transition
   *
   *  @returns True when node successfully transitioned
   *  @returns False when transition failed
   */
  bool Transition(int const transition)
  {
    // We create the request and set the transition
    auto request = std::make_shared<lifecycle_msgs::srv::ChangeState::Request>();
    request->transition.id = transition;

    auto response = rclcpp_avular::QueryService(client_transition_, request, time_out_);

    if(response == std::nullopt)
    {
      RCLCPP_INFO_STREAM(get_logger(), "Could not reach node " << Name() << " for transition request.");
      return false;
    }

    // And we return the result of the actual lifecycle transition
    // TODO(SPANAR-814): For the lifecycle node example, it will return true whether it successfully transitioned or
    // not.
    if((*response)->success)
    {
      RCLCPP_INFO_STREAM(get_logger(), "Transition " << TransitionName(transition)
                                                     << " successfully triggered for node `" << Name() << "`");
      return true;
    }
    else
    {
      RCLCPP_INFO_STREAM(get_logger(), "Failed to trigger transition " << TransitionName(transition) << " for node `"
                                                                       << Name() << "`");
      return false;
    }
  }

  /** \brief Activates the supervised node if it is not yet active, and configures it if necessary
   *
   * \param node_state Current state of the node (obtained earlier)
   *
   * \returns true if success
   * \returns false if failed
   *
   * \remark This is basically a wrapper around Transition by checking with the already known current
   * state, and also configuring before activating if required.
   */
  bool Activate(std::uint8_t const node_state)
  {
    // If the node is already active, there is no need to do anything
    if(node_state == lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE)
    {
      return true;
    }
    // If the node is not yet configured, we first need to do that
    if(node_state == lifecycle_msgs::msg::State::PRIMARY_STATE_UNCONFIGURED)
    {
      if(!Transition(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE))
      {
        // We could not configure the node. Error is reported by Transition, we stop transitioning as something
        // is going wrong.
        return false;
      }
    }
    // Then, finally transition to active
    return Transition(lifecycle_msgs::msg::Transition::TRANSITION_ACTIVATE);
  }

  /** \brief Deactivates the supervised node if it currently is active
   *
   * \param node_state Current state of the node (obtained earlier)
   *
   * \returns true if success
   * \returns false if failed
   *
   * \remark This is basically a wrapper around SupervisedNode.Transition by checking with the already known current
   * state.
   */
  bool Deactivate(std::uint8_t const node_state)
  {
    // If the node is not active, there is no need to do anything
    if(node_state != lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE)
    {
      return true;
    }
    // Transition to inactive
    return Transition(lifecycle_msgs::msg::Transition::TRANSITION_DEACTIVATE);
  }

  /** \brief Gets the name of the supervised node
   *
   * \returns Name of the supervised node
   */
  std::string Name() { return name_; }

private:
  // Replicate get_logger()
  /** \brief Gets the logger to be used
   *
   * \returns The logger of the supervisor node
   * \note This function is implemented to allow easy copy/pasting of code from nodes to this class. We are used to
   * using get_logger() for most logging messages, for which reason we replicate it here.
   */
  rclcpp::Logger get_logger() { return logger_; };

  // Members
  rclcpp::Logger logger_;                      // Logger for log messages
  std::string name_;                           // Name of the supervised node
  NodeTransitionClientPtr client_transition_;  // Client to trigger a transition for the supervised node
  NodeGetStateClientPtr client_get_state_;     // Client to get the state for the supervised node
  std::chrono::seconds time_out_;              // Deadline for the node to respond to a service call
};