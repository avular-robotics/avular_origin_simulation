// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once
#include <rclcpp/logger.hpp>
#include <rclcpp_action/rclcpp_action.hpp>

/**
 * @brief Ostream operator for the ResultCode of an action
 *
 * @param os Stream to write to
 * @param code ResultCode
 * @note Operator isn't namespace or it won't work
 */
std::ostream& operator<<(std::ostream& os, rclcpp_action::ResultCode const& code)
{
  switch(code)
  {
    case rclcpp_action::ResultCode::UNKNOWN:
      os << "UNKNOWN";
      break;
    case rclcpp_action::ResultCode::SUCCEEDED:
      os << "SUCCEEDED";
      break;
    case rclcpp_action::ResultCode::CANCELED:
      os << "CANCELED";
      break;
    case rclcpp_action::ResultCode::ABORTED:
      os << "ABORTED";
      break;
  }
  return os;
}

namespace rclcpp_avular
{

/**
 * @brief Handle to act on goal feedback from an action server
 *
 * @tparam T Type of goal handle
 * @param logger Logger to output to
 * @param goal_handle Goal handle return
 */
template <typename T>
static void ActionGoalHandler(rclcpp::Logger const& logger, T goal_handle)
{
  if(!goal_handle)
  {
    RCLCPP_ERROR(logger, "Goal was rejected by server");
  }
  else
  {
    RCLCPP_INFO(logger, "Goal accepted by server, waiting for result");
  }
}

static void ActionResultHandler(rclcpp::Logger const& logger, rclcpp_action::ResultCode const& code)
{
  RCLCPP_INFO_STREAM(logger, "Action result:" << code);
}
}  // namespace rclcpp_avular
