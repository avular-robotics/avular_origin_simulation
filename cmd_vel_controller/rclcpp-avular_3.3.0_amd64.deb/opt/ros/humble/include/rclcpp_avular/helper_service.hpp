// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <fmt/format.h>
#include <loggercxx/loggercxx.h>

#include <chrono>
#include <future>
#include <optional>
#include <rclcpp/client.hpp>

namespace rclcpp_avular
{

/** @brief Helper function to query a service for a response
 *
 * @param client Service client constructed to communicate with service
 * @param request Request message
 * @param time_out Timeout accepted for service call
 *
 * @returns std::nullopt if request failed
 * @returns std::optional<T> if request succeeded
 */
template <class T, class Rep, class Period>
std::optional<std::shared_ptr<typename T::Response>> QueryService(std::shared_ptr<rclcpp::Client<T>> client,
                                                                  std::shared_ptr<typename T::Request> request,
                                                                  std::chrono::duration<Rep, Period> const& time_out)
{
  // First check if the service is available, before sending the actual request.
  if(!client->wait_for_service(time_out))
  {
    LOGGERCXX_WARN(fmt::format("{}: Service is not available.", client->get_service_name()).c_str());
    return std::nullopt;
  }

  // We send the service request for asking the current
  // state of the lc_talker node.
  auto future_result = client->async_send_request(request).future.share();

  // Let's wait until we have the answer from the node.
  // If the request times out, we return an unknown state.
  auto future_status = future_result.wait_for(time_out);

  if(future_status != std::future_status::ready)
  {
    LOGGERCXX_WARN(fmt::format("{}: Service response timed out.", client->get_service_name()).c_str());
    return std::nullopt;
  }

  // We have an successful answer. So let's print the current state.
  if(future_result.get())
  {
    return future_result.get();
  }
  else
  {
    return std::nullopt;
  }
}

}  // namespace rclcpp_avular