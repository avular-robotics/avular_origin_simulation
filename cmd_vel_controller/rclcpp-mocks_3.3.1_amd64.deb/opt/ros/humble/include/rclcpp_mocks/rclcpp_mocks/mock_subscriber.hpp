// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <gmock/gmock.h>

#include <memory>
#include <rclcpp/node.hpp>
#include <rclcpp/subscription.hpp>
#include <rclcpp_avular/qos.hpp>

namespace testing
{
template <class TMessage>
class MockSubscriber
{
public:
  MockSubscriber(const std::shared_ptr<rclcpp::Node> node_handle, const std::string &topic_name,
                 rclcpp::QoS const &qos_profile = rclcpp_avular::qos::Default())
      : node_handle_(node_handle)
  {
    subscription_ = node_handle->create_subscription<TMessage>(topic_name, qos_profile,
                                                               [this](std::shared_ptr<TMessage> message)
                                                               {
                                                                 message_ = message;
                                                                 ReceiveMessage(message);
                                                               });
  }

  std::shared_ptr<TMessage> LastMessage()
  {
    if(!message_)
    {
      throw std::runtime_error("No message received.");
    }
    return message_;
  }

  MOCK_METHOD(void, ReceiveMessage, (typename TMessage::SharedPtr), ());

private:
  std::shared_ptr<rclcpp::Node> node_handle_;
  rclcpp::Subscription<TMessage>::SharedPtr subscription_;
  std::shared_ptr<TMessage> message_;
};
}  // namespace testing