// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <fmt/format.h>
#include <gmock/gmock.h>

#include <rclcpp/node.hpp>
#include <rclcpp/service.hpp>

namespace testing
{
template <class TService>
class MockServiceServer
{
public:
  MockServiceServer(const std::shared_ptr<rclcpp::Node> node_handle, const std::string &service_name)
      : node_handle_(node_handle)
  {
    callback_group_ = node_handle->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    server_ = node_handle->create_service<TService>(
        service_name,
        [this](std::shared_ptr<typename TService::Request> const request,
               std::shared_ptr<typename TService::Response> const response)
        {
          request_ = request;
          *response = HandleRequest(request);
        },
        rmw_qos_profile_services_default, callback_group_);
  }

  std::shared_ptr<typename TService::Request> LastRequest()
  {
    if(!request_)
    {
      throw std::runtime_error("No request received.");
    }
    return request_;
  }

  MOCK_METHOD(typename TService::Response, HandleRequest, (typename TService::Request::SharedPtr), ());

private:
  std::shared_ptr<rclcpp::Node> node_handle_;
  rclcpp::CallbackGroup::SharedPtr callback_group_;
  rclcpp::Service<TService>::SharedPtr server_;
  std::shared_ptr<typename TService::Request> request_;
};
}  // namespace testing