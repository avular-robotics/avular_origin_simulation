// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <gmock/gmock.h>

#include <rclcpp_lifecycle/lifecycle_node.hpp>

namespace testing
{
class MockLifecycleNode : public rclcpp_lifecycle::LifecycleNode
{
public:
  MockLifecycleNode(std::string const& node_name) : LifecycleNode(node_name, rclcpp::NodeOptions()) {}

  rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_configure(
      rclcpp_lifecycle::State const&) override
  {
    return OnConfigure();
  }
  rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_activate(
      rclcpp_lifecycle::State const&) override
  {
    return OnActivate();
  }
  rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_deactivate(
      rclcpp_lifecycle::State const&) override
  {
    return OnDeactivate();
  }
  rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_cleanup(
      rclcpp_lifecycle::State const&) override
  {
    return OnCleanup();
  }
  rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_shutdown(
      rclcpp_lifecycle::State const&) override
  {
    return OnShutdown();
  }

  MOCK_METHOD(CallbackReturn, OnConfigure, (), ());
  MOCK_METHOD(CallbackReturn, OnActivate, (), ());
  MOCK_METHOD(CallbackReturn, OnDeactivate, (), ());
  MOCK_METHOD(CallbackReturn, OnCleanup, (), ());
  MOCK_METHOD(CallbackReturn, OnShutdown, (), ());

  std::string GetStateString() { return get_current_state().label(); }
};
}  // namespace testing