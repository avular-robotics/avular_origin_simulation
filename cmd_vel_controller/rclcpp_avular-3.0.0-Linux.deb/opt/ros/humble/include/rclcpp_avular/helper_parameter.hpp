// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once
#include <fmt/format.h>

#include <optional>
#include <rcl_interfaces/msg/parameter_descriptor.hpp>
#include <rclcpp/node.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>

namespace rclcpp_avular
{

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, and provide a description. Note that this method
 * declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @tparam NodeType Type of the ROS2 node.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @return auto parameter value.
 */
template <typename T, typename NodeType>
T DeclareParameter(NodeType* node_ptr, const std::string& name, const bool read_only = true,
                   const std::string& description = "", const T default_value = T())
{
  rcl_interfaces::msg::ParameterDescriptor param_descriptor;
  param_descriptor.description = description;
  param_descriptor.read_only = read_only;

  return node_ptr->template declare_parameter<T>(name, default_value, param_descriptor);
}

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, provide upper and lower bounds, set a minimum step
 * size, and provide a description. Note that this method declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @tparam NodeType Type of the ROS2 node.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @param range Range of the parameter (from, to).
 * @param step_size (optional) Size of valid steps between the lower and upper bound (only valid for double/int).
 * @return auto parameter value.
 */
template <typename T, typename NodeType>
T DeclareParameter(NodeType* node_ptr, const std::string& name, const bool read_only, const std::string& description,
                   const std::optional<T> default_value, const std::pair<T, T> range, const T step_size = T())
{
  static_assert(std::is_same_v<int, T> || std::is_same_v<double, T>,
                "Parameter type must be int or double when providing a range or step size.");

  rcl_interfaces::msg::ParameterDescriptor param_descriptor;
  param_descriptor.description = description;
  param_descriptor.read_only = read_only;
  T initial_value = default_value.value_or(T());
  if constexpr(std::is_same_v<int, T>)
  {
    param_descriptor.integer_range.resize(1);
    param_descriptor.integer_range[0].from_value = range.first;
    param_descriptor.integer_range[0].to_value = range.second;
    param_descriptor.integer_range[0].step = step_size;

    initial_value = std::min(std::max(initial_value, range.first), range.second);
  }
  else if constexpr(std::is_same_v<double, T>)
  {
    param_descriptor.floating_point_range.resize(1);
    param_descriptor.floating_point_range[0].from_value = range.first;
    param_descriptor.floating_point_range[0].to_value = range.second;
    param_descriptor.floating_point_range[0].step = step_size;

    initial_value = std::min(std::max(initial_value, range.first), range.second);
  }

  return node_ptr->template declare_parameter<T>(name, initial_value, param_descriptor);
}

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, and provide a description. Note that this method
 * declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @return auto parameter value.
 */
template <typename T>
auto DeclareParameter(rclcpp::Node* node_ptr, const std::string& name, const bool read_only = true,
                      const std::string& description = "", const T default_value = T())
{
  return DeclareParameter<T, rclcpp::Node>(node_ptr, name, read_only, description, default_value);
}

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, and provide a description. Note that this method
 * declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @return auto parameter value.
 */
template <typename T>
auto DeclareParameter(rclcpp_lifecycle::LifecycleNode* node_ptr, const std::string& name, const bool read_only = true,
                      const std::string& description = "", const T default_value = T())
{
  return DeclareParameter<T, rclcpp_lifecycle::LifecycleNode>(node_ptr, name, read_only, description, default_value);
}

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, provide upper and lower bounds, set a minimum step
 * size, and provide a description. Note that this method declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @param range Range of the parameter (from, to).
 * @param step_size (optional) Size of valid steps between the lower and upper bound (only valid for double/int).
 * @return auto parameter value.
 */
template <typename T>
auto DeclareParameter(rclcpp::Node* node_ptr, const std::string& name, const bool read_only,
                      const std::string& description, const std::optional<T> default_value, const std::pair<T, T> range,
                      const T step_size = T())
{
  return DeclareParameter<T, rclcpp::Node>(node_ptr, name, read_only, description, default_value, range, step_size);
}

/**
 * @brief Declares a ros parameter of fixed type, indicated by the template parameter. Using this method, the user can
 * easily define a ros parameter, indicate whether it is read-only, provide upper and lower bounds, set a minimum step
 * size, and provide a description. Note that this method declares a fixed type ros parameter.
 *
 * @tparam T Type of parameter.
 * @param node_ptr Pointer to the ros node from which to declare the parameter.
 * @param name Name of the parameter.
 * @param read_only Whether this parameter is read-only. When set to true, it cannot be updated after configuration.
 * @param description (optional) Description of the parameter.
 * @param default_value (optional) The default value of the parameter.
 * @param range Range of the parameter (from, to).
 * @param step_size (optional) Size of valid steps between the lower and upper bound (only valid for double/int).
 * @return auto parameter value.
 */
template <typename T>
auto DeclareParameter(rclcpp_lifecycle::LifecycleNode* node_ptr, const std::string& name, const bool read_only,
                      const std::string& description, const std::optional<T> default_value, const std::pair<T, T> range,
                      const T step_size = T())
{
  return DeclareParameter<T, rclcpp_lifecycle::LifecycleNode>(node_ptr, name, read_only, description, default_value,
                                                              range, step_size);
}

/**
 * @brief Gets a ROS Parameter for a given node, and declares it if it is not yet declared
 *
 * @tparam T Parameter type
 * @param node_handle Pointer to node to use for obtaining parameter
 * @param parameter_name Parameter name
 * @return T Parameter value
 *
 * @throws std::exception if a parameter with given name and type could not be obtained
 */
template <typename T>
T GetParameter(rclcpp::Node* node_handle, const std::string& parameter_name)
{
  try
  {
    if(!node_handle->has_parameter(parameter_name))
    {
      node_handle->declare_parameter<T>(parameter_name);
    }
    T parameter_value{};
    node_handle->get_parameter(parameter_name, parameter_value);
    return parameter_value;
  }
  catch(const std::exception& ex)
  {
    RCLCPP_ERROR(
        node_handle->get_logger(),
        fmt::format("Something went wrong during parameter \"{}\" configuration: {}", parameter_name, ex.what())
            .c_str());
    throw ex;
  }
}
template <typename T>
T GetParameter(const std::shared_ptr<rclcpp::Node> node_handle, const std::string& parameter_name)
{
  return GetParameter<T>(node_handle.get(), parameter_name);
}

}  // namespace rclcpp_avular
