// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#include <chrono>
#include <rclcpp/time.hpp>
#include <std_msgs/msg/header.hpp>

/**
 * @brief Converts rclcpp::Time into a chrono::time_point
 *
 * @param time ROS time
 * @return std::chrono::system_clock::time_point
 */
inline std::chrono::system_clock::time_point RosToChrono(const rclcpp::Time& time)
{
  return std::chrono::system_clock::time_point(std::chrono::nanoseconds(time.nanoseconds()));
}

inline double HeaderTimeDiff(const std_msgs::msg::Header& lhs, const std_msgs::msg::Header& rhs)
{
  double const dt_sec = static_cast<int>(rhs.stamp.sec) - static_cast<int>(lhs.stamp.sec);
  double const dt_nsec = (static_cast<int>(rhs.stamp.nanosec) - static_cast<int>(lhs.stamp.nanosec)) / 1e9;
  return dt_sec + dt_nsec;
}