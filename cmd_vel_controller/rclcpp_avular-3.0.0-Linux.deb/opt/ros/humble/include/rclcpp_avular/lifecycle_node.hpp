// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <diagnostic_updater/diagnostic_updater.hpp>
#include <rclcpp_components/register_node_macro.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <rclcpp_lifecycle/lifecycle_publisher.hpp>

#include "rclcpp_avular/constants.hpp"
#include "rclcpp_avular/qos.hpp"

namespace rclcpp_avular
{

class LifecycleNode : public rclcpp_lifecycle::LifecycleNode
{
public:
  explicit LifecycleNode(const std::string &node_name, const rclcpp::NodeOptions &options = rclcpp::NodeOptions())
      : rclcpp_lifecycle::LifecycleNode(node_name, options),
        diagnostic_updater_(std::make_shared<diagnostic_updater::Updater>(this, kDiagnosticFrequency))
  {
    InitializeDefaultDiagnostics();
    InitializeCustomDiagnostics();
  };

  explicit LifecycleNode(const std::string &node_name, const std::string &namespace_,
                         const rclcpp::NodeOptions &options = rclcpp::NodeOptions())
      : rclcpp_lifecycle::LifecycleNode(node_name, namespace_, options),
        diagnostic_updater_(std::make_shared<diagnostic_updater::Updater>(this, kDiagnosticFrequency))
  {
    InitializeDefaultDiagnostics();
    InitializeCustomDiagnostics();
  };

protected:
  template <class T>
  void DeclareParameter(std::string const &param_name)
  {
    try
    {
      this->declare_parameter<T>(param_name);
    }
    catch(const std::exception &ex)
    {
      RCLCPP_FATAL_STREAM(get_logger(), "Something went wrong during parameter \"" << param_name << "\" declaration.");
      std::cerr << "Error information: " << ex.what() << std::endl;
      throw ex;
    }
  }

  template <class T>
  void GetParameter(std::string const &param_name, T *param)
  {
    try
    {
      this->get_parameter(param_name, *param);
    }
    catch(const std::exception &ex)
    {
      RCLCPP_FATAL_STREAM(get_logger(), "Error when obtaining parameter \"" << param_name << "\"");
      std::cerr << "Error information: " << ex.what() << std::endl;
      throw ex;
    }
  }

  /**
   * @brief Disables diagnostic updating
   */
  void DisableDiagnostics();

  /**
   * @brief Initializes custom default diagnostics. By default, this does nothing, but it should be overridden by the
   * subclass if more diagnostics should be added or if the hardwareId should be set.
   */
  virtual void InitializeCustomDiagnostics();

  /**
   * @brief Function that is called every diagnostic update frequency, which can/should be overridden by subclasses for
   * more extensive diagnostics.
   *
   * @param stat StatusWrapper passed by the diagnostic update to which status updates should be applied
   */
  virtual void UpdateCustomDiagnostics(diagnostic_updater::DiagnosticStatusWrapper &stat);

  // Diagnostics
  std::shared_ptr<diagnostic_updater::Updater> diagnostic_updater_;

private:
  /**
   * @brief Initializes the default diagnostics.
   *
   * @note This initializes the HardwareID to "none" by default. If this does not apply to the subclass, it should be
   * overridden in `InitializeCustomDiagnostics`.
   */
  void InitializeDefaultDiagnostics();

  /**
   * @brief Function that is called every diagnostic update frequency,.
   *
   * @param stat StatusWrapper passed by the diagnostic update to which status updates should be applied
   */
  void UpdateDefaultDiagnostics(diagnostic_updater::DiagnosticStatusWrapper &stat);
};

}  // namespace rclcpp_avular