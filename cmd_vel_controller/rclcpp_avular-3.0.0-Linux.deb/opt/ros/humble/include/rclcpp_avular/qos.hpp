// Copyright 2023 Avular B.V.
// All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula

#pragma once

#include <rclcpp/qos.hpp>

namespace rclcpp_avular::qos
{

/**
 * Reliable QoS
 *    - History: Keep last,
 *    - Depth: 10,
 *    - Reliability: Reliable,
 *    - Durability: Volatile,
 *    - Deadline: System default,
 *    - Lifespan: System default,
 *    - Liveliness: System dfault,
 *    - Liveliness lease duration: System default,
 *    - avoid ros namespace conventions: false
 */
inline rclcpp::QoS Reliable()
{
  return rclcpp::SystemDefaultsQoS{}
      .keep_last(10)
      .reliability(rclcpp::ReliabilityPolicy::Reliable)
      .durability(rclcpp::DurabilityPolicy::Volatile);
}

/**
 * Best Effort QoS
 *    - History: Keep last,
 *    - Depth: 1,
 *    - Reliability: Best effort,
 *    - Durability: Volatile,
 *    - Deadline: System default,
 *    - Lifespan: System default,
 *    - Liveliness: System dfault,
 *    - Liveliness lease duration: System default,
 *    - avoid ros namespace conventions: false
 */
inline rclcpp::QoS BestEffort()
{
  return rclcpp::SystemDefaultsQoS{}
      .keep_last(1)
      .reliability(rclcpp::ReliabilityPolicy::BestEffort)
      .durability(rclcpp::DurabilityPolicy::Volatile);
}

/**
 * Default QoS
 * See BestEffort()
 */
inline rclcpp::QoS Default() { return BestEffort(); }

/**
 * Sensor QoS
 * BestEffort QoS with changes:
 *    - Depth: 5
 */
inline rclcpp::QoS SensorData() { return BestEffort().keep_last(5); }

/**
 * Latching Topic QoS
 *    - History: Keep last,
 *    - Depth: 10,
 *    - Reliability: Reliable,
 *    - Durability: Transient Local,
 *    - Deadline: System default,
 *    - Lifespan: System default,
 *    - Liveliness: System dfault,
 *    - Liveliness lease duration: System default,
 *    - avoid ros namespace conventions: false
 */
inline rclcpp::QoS Latching()
{
  return rclcpp::SystemDefaultsQoS{}
      .keep_last(10)
      .reliability(rclcpp::ReliabilityPolicy::Reliable)
      .durability(rclcpp::DurabilityPolicy::TransientLocal);
}

}  // namespace rclcpp_avular::qos