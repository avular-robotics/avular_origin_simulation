// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__origin_msgs__msg__NetworkTelemetry __attribute__((deprecated))
#else
# define DEPRECATED__origin_msgs__msg__NetworkTelemetry __declspec(deprecated)
#endif

namespace origin_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct NetworkTelemetry_
{
  using Type = NetworkTelemetry_<ContainerAllocator>;

  explicit NetworkTelemetry_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cellular_strength = 0;
      this->cellular_operator = "";
      this->wifi_strength = 0;
      this->wifi_ssid = "";
      this->wifi_ip = "";
    }
  }

  explicit NetworkTelemetry_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : cellular_operator(_alloc),
    wifi_ssid(_alloc),
    wifi_ip(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cellular_strength = 0;
      this->cellular_operator = "";
      this->wifi_strength = 0;
      this->wifi_ssid = "";
      this->wifi_ip = "";
    }
  }

  // field types and members
  using _cellular_strength_type =
    int8_t;
  _cellular_strength_type cellular_strength;
  using _cellular_operator_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _cellular_operator_type cellular_operator;
  using _wifi_strength_type =
    int8_t;
  _wifi_strength_type wifi_strength;
  using _wifi_ssid_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _wifi_ssid_type wifi_ssid;
  using _wifi_ip_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _wifi_ip_type wifi_ip;

  // setters for named parameter idiom
  Type & set__cellular_strength(
    const int8_t & _arg)
  {
    this->cellular_strength = _arg;
    return *this;
  }
  Type & set__cellular_operator(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->cellular_operator = _arg;
    return *this;
  }
  Type & set__wifi_strength(
    const int8_t & _arg)
  {
    this->wifi_strength = _arg;
    return *this;
  }
  Type & set__wifi_ssid(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->wifi_ssid = _arg;
    return *this;
  }
  Type & set__wifi_ip(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->wifi_ip = _arg;
    return *this;
  }

  // constant declarations
  static constexpr int8_t CELLULAR_STRENGTH_EXCELLENT =
    4;
  static constexpr int8_t CELLULAR_STRENGTH_GOOD =
    3;
  static constexpr int8_t CELLULAR_STRENGTH_FAIR =
    2;
  static constexpr int8_t CELLULAR_STRENGTH_POOR =
    1;
  static constexpr int8_t CELLULAR_STRENGTH_DISCONNECTED =
    0;
  static constexpr int8_t CELLULAR_STRENGTH_UNKNOWN =
    -1;
  static constexpr int8_t WIFI_STRENGTH_EXCELLENT =
    3;
  static constexpr int8_t WIFI_STRENGTH_FAIR =
    2;
  static constexpr int8_t WIFI_STRENGTH_POOR =
    1;
  static constexpr int8_t WIFI_STRENGTH_DISCONNECTED =
    0;
  static constexpr int8_t WIFI_STRENGTH_UNKNOWN =
    -1;

  // pointer types
  using RawPtr =
    origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> *;
  using ConstRawPtr =
    const origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__origin_msgs__msg__NetworkTelemetry
    std::shared_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__origin_msgs__msg__NetworkTelemetry
    std::shared_ptr<origin_msgs::msg::NetworkTelemetry_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NetworkTelemetry_ & other) const
  {
    if (this->cellular_strength != other.cellular_strength) {
      return false;
    }
    if (this->cellular_operator != other.cellular_operator) {
      return false;
    }
    if (this->wifi_strength != other.wifi_strength) {
      return false;
    }
    if (this->wifi_ssid != other.wifi_ssid) {
      return false;
    }
    if (this->wifi_ip != other.wifi_ip) {
      return false;
    }
    return true;
  }
  bool operator!=(const NetworkTelemetry_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NetworkTelemetry_

// alias to use template instance with default allocator
using NetworkTelemetry =
  origin_msgs::msg::NetworkTelemetry_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_EXCELLENT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_GOOD;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_FAIR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_POOR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_DISCONNECTED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::CELLULAR_STRENGTH_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::WIFI_STRENGTH_EXCELLENT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::WIFI_STRENGTH_FAIR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::WIFI_STRENGTH_POOR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::WIFI_STRENGTH_DISCONNECTED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t NetworkTelemetry_<ContainerAllocator>::WIFI_STRENGTH_UNKNOWN;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__STRUCT_HPP_
