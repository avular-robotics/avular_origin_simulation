// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_
#define ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'wake_up_time'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in srv/EnterLowPowerMode in the package origin_msgs.
typedef struct origin_msgs__srv__EnterLowPowerMode_Request
{
  /// Whether to wake up from low power mode at pre-determined time.
  bool schedule_wakeup;
  /// Time to wake up at, in seconds since epoch in UTC time
  /// Ignored if schedule_wakeup is set to false
  builtin_interfaces__msg__Time wake_up_time;
} origin_msgs__srv__EnterLowPowerMode_Request;

// Struct for a sequence of origin_msgs__srv__EnterLowPowerMode_Request.
typedef struct origin_msgs__srv__EnterLowPowerMode_Request__Sequence
{
  origin_msgs__srv__EnterLowPowerMode_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__srv__EnterLowPowerMode_Request__Sequence;


// Constants defined in the message

/// Constant 'ERROR_NONE'.
/**
  * Indicates the request was accepted without any errors.
  *
  * Succesfully entered low power mode.
 */
enum
{
  origin_msgs__srv__EnterLowPowerMode_Response__ERROR_NONE = 0
};

/// Constant 'ERROR_REJECTED'.
/**
  * Indicates the request was rejected.
  *
  * The system is currently not able to enter low power mode.
  * This could be due to an invalid wake_up_time (for example, one in the past)
 */
enum
{
  origin_msgs__srv__EnterLowPowerMode_Response__ERROR_REJECTED = 1
};

/// Struct defined in srv/EnterLowPowerMode in the package origin_msgs.
typedef struct origin_msgs__srv__EnterLowPowerMode_Response
{
  /// Return code, see above definitions.
  int8_t return_code;
} origin_msgs__srv__EnterLowPowerMode_Response;

// Struct for a sequence of origin_msgs__srv__EnterLowPowerMode_Response.
typedef struct origin_msgs__srv__EnterLowPowerMode_Response__Sequence
{
  origin_msgs__srv__EnterLowPowerMode_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__srv__EnterLowPowerMode_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_
