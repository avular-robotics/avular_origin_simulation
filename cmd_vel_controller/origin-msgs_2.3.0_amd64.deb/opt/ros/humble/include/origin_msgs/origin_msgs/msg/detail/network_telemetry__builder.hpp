// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/network_telemetry__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_NetworkTelemetry_wifi_ip
{
public:
  explicit Init_NetworkTelemetry_wifi_ip(::origin_msgs::msg::NetworkTelemetry & msg)
  : msg_(msg)
  {}
  ::origin_msgs::msg::NetworkTelemetry wifi_ip(::origin_msgs::msg::NetworkTelemetry::_wifi_ip_type arg)
  {
    msg_.wifi_ip = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::NetworkTelemetry msg_;
};

class Init_NetworkTelemetry_wifi_ssid
{
public:
  explicit Init_NetworkTelemetry_wifi_ssid(::origin_msgs::msg::NetworkTelemetry & msg)
  : msg_(msg)
  {}
  Init_NetworkTelemetry_wifi_ip wifi_ssid(::origin_msgs::msg::NetworkTelemetry::_wifi_ssid_type arg)
  {
    msg_.wifi_ssid = std::move(arg);
    return Init_NetworkTelemetry_wifi_ip(msg_);
  }

private:
  ::origin_msgs::msg::NetworkTelemetry msg_;
};

class Init_NetworkTelemetry_wifi_strength
{
public:
  explicit Init_NetworkTelemetry_wifi_strength(::origin_msgs::msg::NetworkTelemetry & msg)
  : msg_(msg)
  {}
  Init_NetworkTelemetry_wifi_ssid wifi_strength(::origin_msgs::msg::NetworkTelemetry::_wifi_strength_type arg)
  {
    msg_.wifi_strength = std::move(arg);
    return Init_NetworkTelemetry_wifi_ssid(msg_);
  }

private:
  ::origin_msgs::msg::NetworkTelemetry msg_;
};

class Init_NetworkTelemetry_cellular_operator
{
public:
  explicit Init_NetworkTelemetry_cellular_operator(::origin_msgs::msg::NetworkTelemetry & msg)
  : msg_(msg)
  {}
  Init_NetworkTelemetry_wifi_strength cellular_operator(::origin_msgs::msg::NetworkTelemetry::_cellular_operator_type arg)
  {
    msg_.cellular_operator = std::move(arg);
    return Init_NetworkTelemetry_wifi_strength(msg_);
  }

private:
  ::origin_msgs::msg::NetworkTelemetry msg_;
};

class Init_NetworkTelemetry_cellular_strength
{
public:
  Init_NetworkTelemetry_cellular_strength()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NetworkTelemetry_cellular_operator cellular_strength(::origin_msgs::msg::NetworkTelemetry::_cellular_strength_type arg)
  {
    msg_.cellular_strength = std::move(arg);
    return Init_NetworkTelemetry_cellular_operator(msg_);
  }

private:
  ::origin_msgs::msg::NetworkTelemetry msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::NetworkTelemetry>()
{
  return origin_msgs::msg::builder::Init_NetworkTelemetry_cellular_strength();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__NETWORK_TELEMETRY__BUILDER_HPP_
