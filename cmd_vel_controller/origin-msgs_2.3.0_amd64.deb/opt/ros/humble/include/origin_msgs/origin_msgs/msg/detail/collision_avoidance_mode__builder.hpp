// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from origin_msgs:msg/CollisionAvoidanceMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__BUILDER_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "origin_msgs/msg/detail/collision_avoidance_mode__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace origin_msgs
{

namespace msg
{

namespace builder
{

class Init_CollisionAvoidanceMode_mode
{
public:
  Init_CollisionAvoidanceMode_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::origin_msgs::msg::CollisionAvoidanceMode mode(::origin_msgs::msg::CollisionAvoidanceMode::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::origin_msgs::msg::CollisionAvoidanceMode msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::origin_msgs::msg::CollisionAvoidanceMode>()
{
  return origin_msgs::msg::builder::Init_CollisionAvoidanceMode_mode();
}

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__BUILDER_HPP_
