// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from origin_msgs:msg/GNSSStatus.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_HPP_
#define ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__origin_msgs__msg__GNSSStatus __attribute__((deprecated))
#else
# define DEPRECATED__origin_msgs__msg__GNSSStatus __declspec(deprecated)
#endif

namespace origin_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GNSSStatus_
{
  using Type = GNSSStatus_<ContainerAllocator>;

  explicit GNSSStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
      this->horizontal_position_accuracy = 0.0f;
      this->vertical_position_accuracy = 0.0f;
      this->satellites_visible = 0;
      this->satellites_used = 0;
    }
  }

  explicit GNSSStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
      this->horizontal_position_accuracy = 0.0f;
      this->vertical_position_accuracy = 0.0f;
      this->satellites_visible = 0;
      this->satellites_used = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _status_type =
    int8_t;
  _status_type status;
  using _horizontal_position_accuracy_type =
    float;
  _horizontal_position_accuracy_type horizontal_position_accuracy;
  using _vertical_position_accuracy_type =
    float;
  _vertical_position_accuracy_type vertical_position_accuracy;
  using _satellites_visible_type =
    uint8_t;
  _satellites_visible_type satellites_visible;
  using _satellites_used_type =
    uint8_t;
  _satellites_used_type satellites_used;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__status(
    const int8_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__horizontal_position_accuracy(
    const float & _arg)
  {
    this->horizontal_position_accuracy = _arg;
    return *this;
  }
  Type & set__vertical_position_accuracy(
    const float & _arg)
  {
    this->vertical_position_accuracy = _arg;
    return *this;
  }
  Type & set__satellites_visible(
    const uint8_t & _arg)
  {
    this->satellites_visible = _arg;
    return *this;
  }
  Type & set__satellites_used(
    const uint8_t & _arg)
  {
    this->satellites_used = _arg;
    return *this;
  }

  // constant declarations
  static constexpr int8_t STATUS_NO_FIX =
    -1;
  static constexpr int8_t STATUS_2D_FIX =
    0;
  static constexpr int8_t STATUS_3D_FIX =
    1;
  static constexpr int8_t STATUS_RTK_FLOAT =
    2;
  static constexpr int8_t STATUS_RTK_FIX =
    3;

  // pointer types
  using RawPtr =
    origin_msgs::msg::GNSSStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const origin_msgs::msg::GNSSStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      origin_msgs::msg::GNSSStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      origin_msgs::msg::GNSSStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__origin_msgs__msg__GNSSStatus
    std::shared_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__origin_msgs__msg__GNSSStatus
    std::shared_ptr<origin_msgs::msg::GNSSStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GNSSStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    if (this->horizontal_position_accuracy != other.horizontal_position_accuracy) {
      return false;
    }
    if (this->vertical_position_accuracy != other.vertical_position_accuracy) {
      return false;
    }
    if (this->satellites_visible != other.satellites_visible) {
      return false;
    }
    if (this->satellites_used != other.satellites_used) {
      return false;
    }
    return true;
  }
  bool operator!=(const GNSSStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GNSSStatus_

// alias to use template instance with default allocator
using GNSSStatus =
  origin_msgs::msg::GNSSStatus_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t GNSSStatus_<ContainerAllocator>::STATUS_NO_FIX;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t GNSSStatus_<ContainerAllocator>::STATUS_2D_FIX;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t GNSSStatus_<ContainerAllocator>::STATUS_3D_FIX;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t GNSSStatus_<ContainerAllocator>::STATUS_RTK_FLOAT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t GNSSStatus_<ContainerAllocator>::STATUS_RTK_FIX;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace origin_msgs

#endif  // ORIGIN_MSGS__MSG__DETAIL__GNSS_STATUS__STRUCT_HPP_
