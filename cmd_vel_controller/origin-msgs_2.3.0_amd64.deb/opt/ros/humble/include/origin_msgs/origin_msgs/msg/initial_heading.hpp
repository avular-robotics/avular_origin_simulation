// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__INITIAL_HEADING_HPP_
#define ORIGIN_MSGS__MSG__INITIAL_HEADING_HPP_

#include "origin_msgs/msg/detail/initial_heading__struct.hpp"
#include "origin_msgs/msg/detail/initial_heading__builder.hpp"
#include "origin_msgs/msg/detail/initial_heading__traits.hpp"
#include "origin_msgs/msg/detail/initial_heading__type_support.hpp"

#endif  // ORIGIN_MSGS__MSG__INITIAL_HEADING_HPP_
