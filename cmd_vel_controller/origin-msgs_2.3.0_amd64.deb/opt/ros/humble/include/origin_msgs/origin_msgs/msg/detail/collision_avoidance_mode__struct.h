// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:msg/CollisionAvoidanceMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__STRUCT_H_
#define ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'USE_ALL_ULTRASONIC_SENSORS'.
enum
{
  origin_msgs__msg__CollisionAvoidanceMode__USE_ALL_ULTRASONIC_SENSORS = 0
};

/// Constant 'USE_FRONT_ULTRASONIC_SENSORS'.
enum
{
  origin_msgs__msg__CollisionAvoidanceMode__USE_FRONT_ULTRASONIC_SENSORS = 1
};

/// Constant 'USE_BACK_ULTRASONIC_SENSORS'.
enum
{
  origin_msgs__msg__CollisionAvoidanceMode__USE_BACK_ULTRASONIC_SENSORS = 2
};

/// Constant 'DISABLE_COLLISION_AVOIDANCE'.
enum
{
  origin_msgs__msg__CollisionAvoidanceMode__DISABLE_COLLISION_AVOIDANCE = 3
};

/// Struct defined in msg/CollisionAvoidanceMode in the package origin_msgs.
/**
  * This message can be used to control what sensors should be used for collision
  * avoidance. 
 */
typedef struct origin_msgs__msg__CollisionAvoidanceMode
{
  uint8_t mode;
} origin_msgs__msg__CollisionAvoidanceMode;

// Struct for a sequence of origin_msgs__msg__CollisionAvoidanceMode.
typedef struct origin_msgs__msg__CollisionAvoidanceMode__Sequence
{
  origin_msgs__msg__CollisionAvoidanceMode * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__msg__CollisionAvoidanceMode__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__MSG__DETAIL__COLLISION_AVOIDANCE_MODE__STRUCT_H_
