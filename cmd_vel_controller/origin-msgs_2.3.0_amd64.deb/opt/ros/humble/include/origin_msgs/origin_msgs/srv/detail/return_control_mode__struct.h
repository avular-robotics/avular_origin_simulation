// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from origin_msgs:srv/ReturnControlMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__STRUCT_H_
#define ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'mode_from'
#include "origin_msgs/msg/detail/control_mode__struct.h"

/// Struct defined in srv/ReturnControlMode in the package origin_msgs.
typedef struct origin_msgs__srv__ReturnControlMode_Request
{
  /// Mode expect to return the control mode from
  origin_msgs__msg__ControlMode mode_from;
} origin_msgs__srv__ReturnControlMode_Request;

// Struct for a sequence of origin_msgs__srv__ReturnControlMode_Request.
typedef struct origin_msgs__srv__ReturnControlMode_Request__Sequence
{
  origin_msgs__srv__ReturnControlMode_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__srv__ReturnControlMode_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/ReturnControlMode in the package origin_msgs.
typedef struct origin_msgs__srv__ReturnControlMode_Response
{
  bool success;
  /// Message containing either:
  /// * Success message
  /// * Reason why the request failed/was rejected
  rosidl_runtime_c__String message;
} origin_msgs__srv__ReturnControlMode_Response;

// Struct for a sequence of origin_msgs__srv__ReturnControlMode_Response.
typedef struct origin_msgs__srv__ReturnControlMode_Response__Sequence
{
  origin_msgs__srv__ReturnControlMode_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} origin_msgs__srv__ReturnControlMode_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__STRUCT_H_
