// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:msg/GNSSStatus.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__GNSS_STATUS_H_
#define ORIGIN_MSGS__MSG__GNSS_STATUS_H_

#include "origin_msgs/msg/detail/gnss_status__struct.h"
#include "origin_msgs/msg/detail/gnss_status__functions.h"
#include "origin_msgs/msg/detail/gnss_status__type_support.h"

#endif  // ORIGIN_MSGS__MSG__GNSS_STATUS_H_
