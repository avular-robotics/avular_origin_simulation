// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:msg/NetworkTelemetry.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__NETWORK_TELEMETRY_H_
#define ORIGIN_MSGS__MSG__NETWORK_TELEMETRY_H_

#include "origin_msgs/msg/detail/network_telemetry__struct.h"
#include "origin_msgs/msg/detail/network_telemetry__functions.h"
#include "origin_msgs/msg/detail/network_telemetry__type_support.h"

#endif  // ORIGIN_MSGS__MSG__NETWORK_TELEMETRY_H_
