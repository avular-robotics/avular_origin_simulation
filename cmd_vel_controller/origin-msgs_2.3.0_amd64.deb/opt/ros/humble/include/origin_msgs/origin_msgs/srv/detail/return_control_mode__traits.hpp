// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from origin_msgs:srv/ReturnControlMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__TRAITS_HPP_
#define ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "origin_msgs/srv/detail/return_control_mode__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'mode_from'
#include "origin_msgs/msg/detail/control_mode__traits.hpp"

namespace origin_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const ReturnControlMode_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: mode_from
  {
    out << "mode_from: ";
    to_flow_style_yaml(msg.mode_from, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ReturnControlMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: mode_from
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode_from:\n";
    to_block_style_yaml(msg.mode_from, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ReturnControlMode_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace origin_msgs

namespace rosidl_generator_traits
{

[[deprecated("use origin_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const origin_msgs::srv::ReturnControlMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  origin_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use origin_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const origin_msgs::srv::ReturnControlMode_Request & msg)
{
  return origin_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<origin_msgs::srv::ReturnControlMode_Request>()
{
  return "origin_msgs::srv::ReturnControlMode_Request";
}

template<>
inline const char * name<origin_msgs::srv::ReturnControlMode_Request>()
{
  return "origin_msgs/srv/ReturnControlMode_Request";
}

template<>
struct has_fixed_size<origin_msgs::srv::ReturnControlMode_Request>
  : std::integral_constant<bool, has_fixed_size<origin_msgs::msg::ControlMode>::value> {};

template<>
struct has_bounded_size<origin_msgs::srv::ReturnControlMode_Request>
  : std::integral_constant<bool, has_bounded_size<origin_msgs::msg::ControlMode>::value> {};

template<>
struct is_message<origin_msgs::srv::ReturnControlMode_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace origin_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const ReturnControlMode_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ReturnControlMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ReturnControlMode_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace origin_msgs

namespace rosidl_generator_traits
{

[[deprecated("use origin_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const origin_msgs::srv::ReturnControlMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  origin_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use origin_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const origin_msgs::srv::ReturnControlMode_Response & msg)
{
  return origin_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<origin_msgs::srv::ReturnControlMode_Response>()
{
  return "origin_msgs::srv::ReturnControlMode_Response";
}

template<>
inline const char * name<origin_msgs::srv::ReturnControlMode_Response>()
{
  return "origin_msgs/srv/ReturnControlMode_Response";
}

template<>
struct has_fixed_size<origin_msgs::srv::ReturnControlMode_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<origin_msgs::srv::ReturnControlMode_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<origin_msgs::srv::ReturnControlMode_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<origin_msgs::srv::ReturnControlMode>()
{
  return "origin_msgs::srv::ReturnControlMode";
}

template<>
inline const char * name<origin_msgs::srv::ReturnControlMode>()
{
  return "origin_msgs/srv/ReturnControlMode";
}

template<>
struct has_fixed_size<origin_msgs::srv::ReturnControlMode>
  : std::integral_constant<
    bool,
    has_fixed_size<origin_msgs::srv::ReturnControlMode_Request>::value &&
    has_fixed_size<origin_msgs::srv::ReturnControlMode_Response>::value
  >
{
};

template<>
struct has_bounded_size<origin_msgs::srv::ReturnControlMode>
  : std::integral_constant<
    bool,
    has_bounded_size<origin_msgs::srv::ReturnControlMode_Request>::value &&
    has_bounded_size<origin_msgs::srv::ReturnControlMode_Response>::value
  >
{
};

template<>
struct is_service<origin_msgs::srv::ReturnControlMode>
  : std::true_type
{
};

template<>
struct is_service_request<origin_msgs::srv::ReturnControlMode_Request>
  : std::true_type
{
};

template<>
struct is_service_response<origin_msgs::srv::ReturnControlMode_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // ORIGIN_MSGS__SRV__DETAIL__RETURN_CONTROL_MODE__TRAITS_HPP_
