// generated from rosidl_generator_c/resource/idl.h.em
// with input from origin_msgs:msg/CollisionAvoidanceMode.idl
// generated code does not contain a copyright notice

#ifndef ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_H_
#define ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_H_

#include "origin_msgs/msg/detail/collision_avoidance_mode__struct.h"
#include "origin_msgs/msg/detail/collision_avoidance_mode__functions.h"
#include "origin_msgs/msg/detail/collision_avoidance_mode__type_support.h"

#endif  // ORIGIN_MSGS__MSG__COLLISION_AVOIDANCE_MODE_H_
